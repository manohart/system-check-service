/**
 * Spring Data JPA repositories.
 */
package org.mano.xtp.repository;
