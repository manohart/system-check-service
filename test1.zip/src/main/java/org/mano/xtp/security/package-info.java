/**
 * Spring Security configuration.
 */
package org.mano.xtp.security;
