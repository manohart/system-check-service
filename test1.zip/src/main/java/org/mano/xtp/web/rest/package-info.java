/**
 * Spring MVC REST controllers.
 */
package org.mano.xtp.web.rest;
