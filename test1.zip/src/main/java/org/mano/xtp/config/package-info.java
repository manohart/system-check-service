/**
 * Spring Framework configuration files.
 */
package org.mano.xtp.config;
