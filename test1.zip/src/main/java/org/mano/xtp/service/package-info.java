/**
 * Service layer beans.
 */
package org.mano.xtp.service;
