/**
 * JPA domain objects.
 */
package org.mano.xtp.domain;
