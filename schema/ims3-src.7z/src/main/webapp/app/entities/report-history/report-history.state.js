(function() {
    'use strict';

    angular
        .module('imsApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('report-history', {
            parent: 'entity',
            url: '/report-history',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'ReportHistories'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/report-history/report-histories.html',
                    controller: 'ReportHistoryController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
            }
        })
        .state('report-history-detail', {
            parent: 'entity',
            url: '/report-history/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'ReportHistory'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/report-history/report-history-detail.html',
                    controller: 'ReportHistoryDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'ReportHistory', function($stateParams, ReportHistory) {
                    return ReportHistory.get({id : $stateParams.id}).$promise;
                }]
            }
        })
        .state('report-history.new', {
            parent: 'report-history',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/report-history/report-history-dialog.html',
                    controller: 'ReportHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                initialStatus: null,
                                finalStatus: null,
                                businessDate: null,
                                comment: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('report-history', null, { reload: true });
                }, function() {
                    $state.go('report-history');
                });
            }]
        })
        .state('report-history.edit', {
            parent: 'report-history',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/report-history/report-history-dialog.html',
                    controller: 'ReportHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['ReportHistory', function(ReportHistory) {
                            return ReportHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('report-history', null, { reload: true });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('report-history.delete', {
            parent: 'report-history',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/report-history/report-history-delete-dialog.html',
                    controller: 'ReportHistoryDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['ReportHistory', function(ReportHistory) {
                            return ReportHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('report-history', null, { reload: true });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
