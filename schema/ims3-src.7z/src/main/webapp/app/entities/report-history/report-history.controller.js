(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('ReportHistoryController', ReportHistoryController);

    ReportHistoryController.$inject = ['$scope', '$state', 'ReportHistory'];

    function ReportHistoryController ($scope, $state, ReportHistory) {
        var vm = this;
        
        vm.reportHistories = [];

        loadAll();

        function loadAll() {
            ReportHistory.query(function(result) {
                vm.reportHistories = result;
            });
        }
    }
})();
