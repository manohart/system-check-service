(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('ReportHistoryDeleteController',ReportHistoryDeleteController);

    ReportHistoryDeleteController.$inject = ['$uibModalInstance', 'entity', 'ReportHistory'];

    function ReportHistoryDeleteController($uibModalInstance, entity, ReportHistory) {
        var vm = this;

        vm.reportHistory = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;
        
        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            ReportHistory.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
