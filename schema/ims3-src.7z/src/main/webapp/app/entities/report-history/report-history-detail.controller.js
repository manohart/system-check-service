(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('ReportHistoryDetailController', ReportHistoryDetailController);

    ReportHistoryDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'entity', 'ReportHistory', 'Report', 'ReportDetailHistory'];

    function ReportHistoryDetailController($scope, $rootScope, $stateParams, entity, ReportHistory, Report, ReportDetailHistory) {
        var vm = this;

        vm.reportHistory = entity;

        var unsubscribe = $rootScope.$on('imsApp:reportHistoryUpdate', function(event, result) {
            vm.reportHistory = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
