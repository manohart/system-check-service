(function() {
    'use strict';
    angular
        .module('imsApp')
        .factory('ReportHistory', ReportHistory);

    ReportHistory.$inject = ['$resource', 'DateUtils'];

    function ReportHistory ($resource, DateUtils) {
        var resourceUrl =  'api/report-histories/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                        data.businessDate = DateUtils.convertLocalDateFromServer(data.businessDate);
                    }
                    return data;
                }
            },
            'update': {
                method: 'PUT',
                transformRequest: function (data) {
                    data.businessDate = DateUtils.convertLocalDateToServer(data.businessDate);
                    return angular.toJson(data);
                }
            },
            'save': {
                method: 'POST',
                transformRequest: function (data) {
                    data.businessDate = DateUtils.convertLocalDateToServer(data.businessDate);
                    return angular.toJson(data);
                }
            }
        });
    }
})();
