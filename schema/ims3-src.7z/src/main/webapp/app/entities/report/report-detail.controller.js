(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('ReportDetailController', ReportDetailController);

    ReportDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'entity', 'Report', 'Job', 'ReportDistribution', 'DbCheck', 'ReportHistory'];

    function ReportDetailController($scope, $rootScope, $stateParams, entity, Report, Job, ReportDistribution, DbCheck, ReportHistory) {
        var vm = this;

        vm.report = entity;

        var unsubscribe = $rootScope.$on('imsApp:reportUpdate', function(event, result) {
            vm.report = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
