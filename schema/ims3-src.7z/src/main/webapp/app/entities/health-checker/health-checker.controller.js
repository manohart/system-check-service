(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('HealthCheckerController', HealthCheckerController);

    HealthCheckerController.$inject = ['$scope', '$state', 'HealthChecker'];

    function HealthCheckerController ($scope, $state, HealthChecker) {
        var vm = this;
        
        vm.healthCheckers = [];

        loadAll();

        function loadAll() {
            HealthChecker.query(function(result) {
                vm.healthCheckers = result;
            });
        }
    }
})();
