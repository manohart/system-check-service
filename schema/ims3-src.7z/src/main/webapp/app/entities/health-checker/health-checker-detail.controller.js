(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('HealthCheckerDetailController', HealthCheckerDetailController);

    HealthCheckerDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'entity', 'HealthChecker', 'DbCheck'];

    function HealthCheckerDetailController($scope, $rootScope, $stateParams, entity, HealthChecker, DbCheck) {
        var vm = this;

        vm.healthChecker = entity;

        var unsubscribe = $rootScope.$on('imsApp:healthCheckerUpdate', function(event, result) {
            vm.healthChecker = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
