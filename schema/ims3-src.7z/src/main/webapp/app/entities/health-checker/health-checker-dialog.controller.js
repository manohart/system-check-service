(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('HealthCheckerDialogController', HealthCheckerDialogController);

    HealthCheckerDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'HealthChecker', 'DbCheck'];

    function HealthCheckerDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, HealthChecker, DbCheck) {
        var vm = this;

        vm.healthChecker = entity;
        vm.clear = clear;
        vm.save = save;
        vm.dbchecks = DbCheck.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.healthChecker.id !== null) {
                HealthChecker.update(vm.healthChecker, onSaveSuccess, onSaveError);
            } else {
                HealthChecker.save(vm.healthChecker, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('imsApp:healthCheckerUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }


    }
})();
