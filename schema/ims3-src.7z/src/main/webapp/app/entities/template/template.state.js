(function() {
    'use strict';

    angular
        .module('imsApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('template', {
            parent: 'entity',
            url: '/template',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'Templates'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/template/templates.html',
                    controller: 'TemplateController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
            }
        })
        .state('template-detail', {
            parent: 'entity',
            url: '/template/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'Template'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/template/template-detail.html',
                    controller: 'TemplateDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'Template', function($stateParams, Template) {
                    return Template.get({id : $stateParams.id}).$promise;
                }]
            }
        })
        .state('template.new', {
            parent: 'template',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/template/template-dialog.html',
                    controller: 'TemplateDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                name: null,
                                description: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('template', null, { reload: true });
                }, function() {
                    $state.go('template');
                });
            }]
        })
        .state('template.edit', {
            parent: 'template',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/template/template-dialog.html',
                    controller: 'TemplateDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['Template', function(Template) {
                            return Template.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('template', null, { reload: true });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('template.delete', {
            parent: 'template',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/template/template-delete-dialog.html',
                    controller: 'TemplateDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['Template', function(Template) {
                            return Template.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('template', null, { reload: true });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
