(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('TemplateDetailController', TemplateDetailController);

    TemplateDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'entity', 'Template', 'Lob'];

    function TemplateDetailController($scope, $rootScope, $stateParams, entity, Template, Lob) {
        var vm = this;

        vm.template = entity;

        var unsubscribe = $rootScope.$on('imsApp:templateUpdate', function(event, result) {
            vm.template = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
