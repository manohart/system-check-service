(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('TemplateController', TemplateController);

    TemplateController.$inject = ['$scope', '$state', 'Template'];

    function TemplateController ($scope, $state, Template) {
        var vm = this;
        
        vm.templates = [];

        loadAll();

        function loadAll() {
            Template.query(function(result) {
                vm.templates = result;
            });
        }
    }
})();
