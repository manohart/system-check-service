(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('ReportDistributionController', ReportDistributionController);

    ReportDistributionController.$inject = ['$scope', '$state', 'ReportDistribution'];

    function ReportDistributionController ($scope, $state, ReportDistribution) {
        var vm = this;
        
        vm.reportDistributions = [];

        loadAll();

        function loadAll() {
            ReportDistribution.query(function(result) {
                vm.reportDistributions = result;
            });
        }
    }
})();
