(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('ReportDistributionDetailController', ReportDistributionDetailController);

    ReportDistributionDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'entity', 'ReportDistribution', 'EmailConfig', 'Report'];

    function ReportDistributionDetailController($scope, $rootScope, $stateParams, entity, ReportDistribution, EmailConfig, Report) {
        var vm = this;

        vm.reportDistribution = entity;

        var unsubscribe = $rootScope.$on('imsApp:reportDistributionUpdate', function(event, result) {
            vm.reportDistribution = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
