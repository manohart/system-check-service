(function() {
    'use strict';
    angular
        .module('imsApp')
        .factory('ReportDistribution', ReportDistribution);

    ReportDistribution.$inject = ['$resource'];

    function ReportDistribution ($resource) {
        var resourceUrl =  'api/report-distributions/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                    }
                    return data;
                }
            },
            'update': { method:'PUT' }
        });
    }
})();
