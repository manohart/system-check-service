(function() {
    'use strict';

    angular
        .module('imsApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('report-distribution', {
            parent: 'entity',
            url: '/report-distribution',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'ReportDistributions'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/report-distribution/report-distributions.html',
                    controller: 'ReportDistributionController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
            }
        })
        .state('report-distribution-detail', {
            parent: 'entity',
            url: '/report-distribution/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'ReportDistribution'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/report-distribution/report-distribution-detail.html',
                    controller: 'ReportDistributionDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'ReportDistribution', function($stateParams, ReportDistribution) {
                    return ReportDistribution.get({id : $stateParams.id}).$promise;
                }]
            }
        })
        .state('report-distribution.new', {
            parent: 'report-distribution',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/report-distribution/report-distribution-dialog.html',
                    controller: 'ReportDistributionDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                name: null,
                                skipEmptyReport: null,
                                isActive: false,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('report-distribution', null, { reload: true });
                }, function() {
                    $state.go('report-distribution');
                });
            }]
        })
        .state('report-distribution.edit', {
            parent: 'report-distribution',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/report-distribution/report-distribution-dialog.html',
                    controller: 'ReportDistributionDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['ReportDistribution', function(ReportDistribution) {
                            return ReportDistribution.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('report-distribution', null, { reload: true });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('report-distribution.delete', {
            parent: 'report-distribution',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/report-distribution/report-distribution-delete-dialog.html',
                    controller: 'ReportDistributionDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['ReportDistribution', function(ReportDistribution) {
                            return ReportDistribution.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('report-distribution', null, { reload: true });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
