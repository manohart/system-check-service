(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('ReportDistributionDialogController', ReportDistributionDialogController);

    ReportDistributionDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'ReportDistribution', 'EmailConfig', 'Report'];

    function ReportDistributionDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, ReportDistribution, EmailConfig, Report) {
        var vm = this;

        vm.reportDistribution = entity;
        vm.clear = clear;
        vm.save = save;
        vm.emailconfigs = EmailConfig.query();
        vm.reports = Report.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.reportDistribution.id !== null) {
                ReportDistribution.update(vm.reportDistribution, onSaveSuccess, onSaveError);
            } else {
                ReportDistribution.save(vm.reportDistribution, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('imsApp:reportDistributionUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }


    }
})();
