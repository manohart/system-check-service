(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('UpstreamDetailController', UpstreamDetailController);

    UpstreamDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'entity', 'Upstream', 'DbCheck'];

    function UpstreamDetailController($scope, $rootScope, $stateParams, entity, Upstream, DbCheck) {
        var vm = this;

        vm.upstream = entity;

        var unsubscribe = $rootScope.$on('imsApp:upstreamUpdate', function(event, result) {
            vm.upstream = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
