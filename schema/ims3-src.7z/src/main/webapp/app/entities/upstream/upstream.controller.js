(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('UpstreamController', UpstreamController);

    UpstreamController.$inject = ['$scope', '$state', 'Upstream'];

    function UpstreamController ($scope, $state, Upstream) {
        var vm = this;
        
        vm.upstreams = [];

        loadAll();

        function loadAll() {
            Upstream.query(function(result) {
                vm.upstreams = result;
            });
        }
    }
})();
