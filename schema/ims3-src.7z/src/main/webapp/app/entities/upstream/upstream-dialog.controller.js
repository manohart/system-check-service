(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('UpstreamDialogController', UpstreamDialogController);

    UpstreamDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'Upstream', 'DbCheck'];

    function UpstreamDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, Upstream, DbCheck) {
        var vm = this;

        vm.upstream = entity;
        vm.clear = clear;
        vm.save = save;
        vm.dbchecks = DbCheck.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.upstream.id !== null) {
                Upstream.update(vm.upstream, onSaveSuccess, onSaveError);
            } else {
                Upstream.save(vm.upstream, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('imsApp:upstreamUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }


    }
})();
