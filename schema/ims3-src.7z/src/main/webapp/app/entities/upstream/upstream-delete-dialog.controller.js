(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('UpstreamDeleteController',UpstreamDeleteController);

    UpstreamDeleteController.$inject = ['$uibModalInstance', 'entity', 'Upstream'];

    function UpstreamDeleteController($uibModalInstance, entity, Upstream) {
        var vm = this;

        vm.upstream = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;
        
        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            Upstream.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
