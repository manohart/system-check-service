(function() {
    'use strict';

    angular
        .module('imsApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('upstream', {
            parent: 'entity',
            url: '/upstream',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'Upstreams'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/upstream/upstreams.html',
                    controller: 'UpstreamController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
            }
        })
        .state('upstream-detail', {
            parent: 'entity',
            url: '/upstream/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'Upstream'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/upstream/upstream-detail.html',
                    controller: 'UpstreamDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'Upstream', function($stateParams, Upstream) {
                    return Upstream.get({id : $stateParams.id}).$promise;
                }]
            }
        })
        .state('upstream.new', {
            parent: 'upstream',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/upstream/upstream-dialog.html',
                    controller: 'UpstreamDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                name: null,
                                ownerEmailId: null,
                                teamDlEmailId: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('upstream', null, { reload: true });
                }, function() {
                    $state.go('upstream');
                });
            }]
        })
        .state('upstream.edit', {
            parent: 'upstream',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/upstream/upstream-dialog.html',
                    controller: 'UpstreamDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['Upstream', function(Upstream) {
                            return Upstream.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('upstream', null, { reload: true });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('upstream.delete', {
            parent: 'upstream',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/upstream/upstream-delete-dialog.html',
                    controller: 'UpstreamDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['Upstream', function(Upstream) {
                            return Upstream.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('upstream', null, { reload: true });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
