(function() {
    'use strict';

    angular
        .module('imsApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('lob', {
            parent: 'entity',
            url: '/lob',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'Lobs'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/lob/lobs.html',
                    controller: 'LobController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
            }
        })
        .state('lob-detail', {
            parent: 'entity',
            url: '/lob/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'Lob'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/lob/lob-detail.html',
                    controller: 'LobDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'Lob', function($stateParams, Lob) {
                    return Lob.get({id : $stateParams.id}).$promise;
                }]
            }
        })
        .state('lob.new', {
            parent: 'lob',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/lob/lob-dialog.html',
                    controller: 'LobDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                name: null,
                                region: null,
                                ownerEmailId: null,
                                leadEmailId: null,
                                reportArchiveFolder: null,
                                sla: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('lob', null, { reload: true });
                }, function() {
                    $state.go('lob');
                });
            }]
        })
        .state('lob.edit', {
            parent: 'lob',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/lob/lob-dialog.html',
                    controller: 'LobDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['Lob', function(Lob) {
                            return Lob.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('lob', null, { reload: true });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('lob.delete', {
            parent: 'lob',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/lob/lob-delete-dialog.html',
                    controller: 'LobDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['Lob', function(Lob) {
                            return Lob.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('lob', null, { reload: true });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
