(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('LobDetailController', LobDetailController);

    LobDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'entity', 'Lob', 'Job', 'EmailConfig', 'Template'];

    function LobDetailController($scope, $rootScope, $stateParams, entity, Lob, Job, EmailConfig, Template) {
        var vm = this;

        vm.lob = entity;

        var unsubscribe = $rootScope.$on('imsApp:lobUpdate', function(event, result) {
            vm.lob = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
