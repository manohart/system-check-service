(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('LobDialogController', LobDialogController);

    LobDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'Lob', 'Job', 'EmailConfig', 'Template'];

    function LobDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, Lob, Job, EmailConfig, Template) {
        var vm = this;

        vm.lob = entity;
        vm.clear = clear;
        vm.save = save;
        vm.jobs = Job.query();
        vm.emailconfigs = EmailConfig.query();
        vm.templates = Template.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.lob.id !== null) {
                Lob.update(vm.lob, onSaveSuccess, onSaveError);
            } else {
                Lob.save(vm.lob, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('imsApp:lobUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }


    }
})();
