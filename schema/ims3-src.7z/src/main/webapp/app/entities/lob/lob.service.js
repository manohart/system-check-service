(function() {
    'use strict';
    angular
        .module('imsApp')
        .factory('Lob', Lob);

    Lob.$inject = ['$resource'];

    function Lob ($resource) {
        var resourceUrl =  'api/lobs/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                    }
                    return data;
                }
            },
            'update': { method:'PUT' }
        });
    }
})();
