(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('DbCheckDialogController', DbCheckDialogController);

    DbCheckDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'DbCheck', 'HealthChecker', 'Report', 'DbNamedSql', 'Upstream'];

    function DbCheckDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, DbCheck, HealthChecker, Report, DbNamedSql, Upstream) {
        var vm = this;

        vm.dbCheck = entity;
        vm.clear = clear;
        vm.save = save;
        vm.healthcheckers = HealthChecker.query();
        vm.reports = Report.query();
        vm.dbnamedsqls = DbNamedSql.query();
        vm.upstreams = Upstream.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.dbCheck.id !== null) {
                DbCheck.update(vm.dbCheck, onSaveSuccess, onSaveError);
            } else {
                DbCheck.save(vm.dbCheck, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('imsApp:dbCheckUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }


    }
})();
