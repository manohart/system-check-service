(function() {
    'use strict';

    angular
        .module('imsApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('db-check', {
            parent: 'entity',
            url: '/db-check',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'DbChecks'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/db-check/db-checks.html',
                    controller: 'DbCheckController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
            }
        })
        .state('db-check-detail', {
            parent: 'entity',
            url: '/db-check/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'DbCheck'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/db-check/db-check-detail.html',
                    controller: 'DbCheckDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'DbCheck', function($stateParams, DbCheck) {
                    return DbCheck.get({id : $stateParams.id}).$promise;
                }]
            }
        })
        .state('db-check.new', {
            parent: 'db-check',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/db-check/db-check-dialog.html',
                    controller: 'DbCheckDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                name: null,
                                sequence: null,
                                queryInput: null,
                                expectation: null,
                                reportIssuesOnly: null,
                                groupColumns: null,
                                runBookLink: null,
                                isActive: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('db-check', null, { reload: true });
                }, function() {
                    $state.go('db-check');
                });
            }]
        })
        .state('db-check.edit', {
            parent: 'db-check',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/db-check/db-check-dialog.html',
                    controller: 'DbCheckDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['DbCheck', function(DbCheck) {
                            return DbCheck.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('db-check', null, { reload: true });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('db-check.delete', {
            parent: 'db-check',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/db-check/db-check-delete-dialog.html',
                    controller: 'DbCheckDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['DbCheck', function(DbCheck) {
                            return DbCheck.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('db-check', null, { reload: true });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
