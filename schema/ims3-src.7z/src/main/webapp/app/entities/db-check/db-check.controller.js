(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('DbCheckController', DbCheckController);

    DbCheckController.$inject = ['$scope', '$state', 'DbCheck'];

    function DbCheckController ($scope, $state, DbCheck) {
        var vm = this;
        
        vm.dbChecks = [];

        loadAll();

        function loadAll() {
            DbCheck.query(function(result) {
                vm.dbChecks = result;
            });
        }
    }
})();
