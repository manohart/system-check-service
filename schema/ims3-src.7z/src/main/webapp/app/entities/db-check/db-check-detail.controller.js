(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('DbCheckDetailController', DbCheckDetailController);

    DbCheckDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'entity', 'DbCheck', 'HealthChecker', 'Report', 'DbNamedSql', 'Upstream'];

    function DbCheckDetailController($scope, $rootScope, $stateParams, entity, DbCheck, HealthChecker, Report, DbNamedSql, Upstream) {
        var vm = this;

        vm.dbCheck = entity;

        var unsubscribe = $rootScope.$on('imsApp:dbCheckUpdate', function(event, result) {
            vm.dbCheck = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
