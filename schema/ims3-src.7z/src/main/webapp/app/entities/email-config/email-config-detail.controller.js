(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('EmailConfigDetailController', EmailConfigDetailController);

    EmailConfigDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'entity', 'EmailConfig', 'Lob', 'ReportDistribution'];

    function EmailConfigDetailController($scope, $rootScope, $stateParams, entity, EmailConfig, Lob, ReportDistribution) {
        var vm = this;

        vm.emailConfig = entity;

        var unsubscribe = $rootScope.$on('imsApp:emailConfigUpdate', function(event, result) {
            vm.emailConfig = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
