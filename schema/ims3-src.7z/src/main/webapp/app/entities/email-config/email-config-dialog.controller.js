(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('EmailConfigDialogController', EmailConfigDialogController);

    EmailConfigDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'EmailConfig', 'Lob', 'ReportDistribution'];

    function EmailConfigDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, EmailConfig, Lob, ReportDistribution) {
        var vm = this;

        vm.emailConfig = entity;
        vm.clear = clear;
        vm.save = save;
        vm.lobs = Lob.query();
        vm.reportdistributions = ReportDistribution.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.emailConfig.id !== null) {
                EmailConfig.update(vm.emailConfig, onSaveSuccess, onSaveError);
            } else {
                EmailConfig.save(vm.emailConfig, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('imsApp:emailConfigUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }


    }
})();
