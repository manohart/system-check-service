(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('EmailConfigDeleteController',EmailConfigDeleteController);

    EmailConfigDeleteController.$inject = ['$uibModalInstance', 'entity', 'EmailConfig'];

    function EmailConfigDeleteController($uibModalInstance, entity, EmailConfig) {
        var vm = this;

        vm.emailConfig = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;
        
        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            EmailConfig.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
