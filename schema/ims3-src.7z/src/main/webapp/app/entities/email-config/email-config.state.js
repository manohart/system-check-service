(function() {
    'use strict';

    angular
        .module('imsApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('email-config', {
            parent: 'entity',
            url: '/email-config',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'EmailConfigs'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/email-config/email-configs.html',
                    controller: 'EmailConfigController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
            }
        })
        .state('email-config-detail', {
            parent: 'entity',
            url: '/email-config/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'EmailConfig'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/email-config/email-config-detail.html',
                    controller: 'EmailConfigDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'EmailConfig', function($stateParams, EmailConfig) {
                    return EmailConfig.get({id : $stateParams.id}).$promise;
                }]
            }
        })
        .state('email-config.new', {
            parent: 'email-config',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/email-config/email-config-dialog.html',
                    controller: 'EmailConfigDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                name: null,
                                description: null,
                                fromAddress: null,
                                toAddress: null,
                                ccAddress: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('email-config', null, { reload: true });
                }, function() {
                    $state.go('email-config');
                });
            }]
        })
        .state('email-config.edit', {
            parent: 'email-config',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/email-config/email-config-dialog.html',
                    controller: 'EmailConfigDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['EmailConfig', function(EmailConfig) {
                            return EmailConfig.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('email-config', null, { reload: true });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('email-config.delete', {
            parent: 'email-config',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/email-config/email-config-delete-dialog.html',
                    controller: 'EmailConfigDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['EmailConfig', function(EmailConfig) {
                            return EmailConfig.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('email-config', null, { reload: true });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
