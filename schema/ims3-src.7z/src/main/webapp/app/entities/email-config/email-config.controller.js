(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('EmailConfigController', EmailConfigController);

    EmailConfigController.$inject = ['$scope', '$state', 'EmailConfig'];

    function EmailConfigController ($scope, $state, EmailConfig) {
        var vm = this;
        
        vm.emailConfigs = [];

        loadAll();

        function loadAll() {
            EmailConfig.query(function(result) {
                vm.emailConfigs = result;
            });
        }
    }
})();
