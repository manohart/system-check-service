(function() {
    'use strict';

    angular
        .module('imsApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('db-named-sql', {
            parent: 'entity',
            url: '/db-named-sql',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'DbNamedSqls'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/db-named-sql/db-named-sqls.html',
                    controller: 'DbNamedSqlController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
            }
        })
        .state('db-named-sql-detail', {
            parent: 'entity',
            url: '/db-named-sql/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'DbNamedSql'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/db-named-sql/db-named-sql-detail.html',
                    controller: 'DbNamedSqlDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'DbNamedSql', function($stateParams, DbNamedSql) {
                    return DbNamedSql.get({id : $stateParams.id}).$promise;
                }]
            }
        })
        .state('db-named-sql.new', {
            parent: 'db-named-sql',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/db-named-sql/db-named-sql-dialog.html',
                    controller: 'DbNamedSqlDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                namespace: null,
                                statementId: null,
                                description: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('db-named-sql', null, { reload: true });
                }, function() {
                    $state.go('db-named-sql');
                });
            }]
        })
        .state('db-named-sql.edit', {
            parent: 'db-named-sql',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/db-named-sql/db-named-sql-dialog.html',
                    controller: 'DbNamedSqlDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['DbNamedSql', function(DbNamedSql) {
                            return DbNamedSql.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('db-named-sql', null, { reload: true });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('db-named-sql.delete', {
            parent: 'db-named-sql',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/db-named-sql/db-named-sql-delete-dialog.html',
                    controller: 'DbNamedSqlDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['DbNamedSql', function(DbNamedSql) {
                            return DbNamedSql.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('db-named-sql', null, { reload: true });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
