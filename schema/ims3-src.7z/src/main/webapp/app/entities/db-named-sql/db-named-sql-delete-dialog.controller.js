(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('DbNamedSqlDeleteController',DbNamedSqlDeleteController);

    DbNamedSqlDeleteController.$inject = ['$uibModalInstance', 'entity', 'DbNamedSql'];

    function DbNamedSqlDeleteController($uibModalInstance, entity, DbNamedSql) {
        var vm = this;

        vm.dbNamedSql = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;
        
        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            DbNamedSql.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
