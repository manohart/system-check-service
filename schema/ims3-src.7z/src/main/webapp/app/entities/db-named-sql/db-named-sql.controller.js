(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('DbNamedSqlController', DbNamedSqlController);

    DbNamedSqlController.$inject = ['$scope', '$state', 'DbNamedSql'];

    function DbNamedSqlController ($scope, $state, DbNamedSql) {
        var vm = this;
        
        vm.dbNamedSqls = [];

        loadAll();

        function loadAll() {
            DbNamedSql.query(function(result) {
                vm.dbNamedSqls = result;
            });
        }
    }
})();
