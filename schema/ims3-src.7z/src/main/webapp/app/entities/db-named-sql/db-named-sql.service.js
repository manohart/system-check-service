(function() {
    'use strict';
    angular
        .module('imsApp')
        .factory('DbNamedSql', DbNamedSql);

    DbNamedSql.$inject = ['$resource'];

    function DbNamedSql ($resource) {
        var resourceUrl =  'api/db-named-sqls/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                    }
                    return data;
                }
            },
            'update': { method:'PUT' }
        });
    }
})();
