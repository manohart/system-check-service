(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('DbNamedSqlDialogController', DbNamedSqlDialogController);

    DbNamedSqlDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'DbNamedSql', 'DbCheck', 'ReportDetailHistory'];

    function DbNamedSqlDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, DbNamedSql, DbCheck, ReportDetailHistory) {
        var vm = this;

        vm.dbNamedSql = entity;
        vm.clear = clear;
        vm.save = save;
        vm.dbchecks = DbCheck.query();
        vm.reportdetailhistories = ReportDetailHistory.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.dbNamedSql.id !== null) {
                DbNamedSql.update(vm.dbNamedSql, onSaveSuccess, onSaveError);
            } else {
                DbNamedSql.save(vm.dbNamedSql, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('imsApp:dbNamedSqlUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }


    }
})();
