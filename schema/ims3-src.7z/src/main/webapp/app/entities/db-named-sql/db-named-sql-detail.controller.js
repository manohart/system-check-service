(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('DbNamedSqlDetailController', DbNamedSqlDetailController);

    DbNamedSqlDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'entity', 'DbNamedSql', 'DbCheck', 'ReportDetailHistory'];

    function DbNamedSqlDetailController($scope, $rootScope, $stateParams, entity, DbNamedSql, DbCheck, ReportDetailHistory) {
        var vm = this;

        vm.dbNamedSql = entity;

        var unsubscribe = $rootScope.$on('imsApp:dbNamedSqlUpdate', function(event, result) {
            vm.dbNamedSql = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
