(function() {
    'use strict';
    angular
        .module('imsApp')
        .factory('ReportDetailHistory', ReportDetailHistory);

    ReportDetailHistory.$inject = ['$resource'];

    function ReportDetailHistory ($resource) {
        var resourceUrl =  'api/report-detail-histories/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                    }
                    return data;
                }
            },
            'update': { method:'PUT' }
        });
    }
})();
