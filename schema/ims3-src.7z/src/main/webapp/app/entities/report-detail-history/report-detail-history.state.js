(function() {
    'use strict';

    angular
        .module('imsApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('report-detail-history', {
            parent: 'entity',
            url: '/report-detail-history',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'ReportDetailHistories'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/report-detail-history/report-detail-histories.html',
                    controller: 'ReportDetailHistoryController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
            }
        })
        .state('report-detail-history-detail', {
            parent: 'entity',
            url: '/report-detail-history/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'ReportDetailHistory'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/report-detail-history/report-detail-history-detail.html',
                    controller: 'ReportDetailHistoryDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'ReportDetailHistory', function($stateParams, ReportDetailHistory) {
                    return ReportDetailHistory.get({id : $stateParams.id}).$promise;
                }]
            }
        })
        .state('report-detail-history.new', {
            parent: 'report-detail-history',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/report-detail-history/report-detail-history-dialog.html',
                    controller: 'ReportDetailHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                records: null,
                                issues: null,
                                initialStatus: null,
                                finalStatus: null,
                                comment: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('report-detail-history', null, { reload: true });
                }, function() {
                    $state.go('report-detail-history');
                });
            }]
        })
        .state('report-detail-history.edit', {
            parent: 'report-detail-history',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/report-detail-history/report-detail-history-dialog.html',
                    controller: 'ReportDetailHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['ReportDetailHistory', function(ReportDetailHistory) {
                            return ReportDetailHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('report-detail-history', null, { reload: true });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('report-detail-history.delete', {
            parent: 'report-detail-history',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/report-detail-history/report-detail-history-delete-dialog.html',
                    controller: 'ReportDetailHistoryDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['ReportDetailHistory', function(ReportDetailHistory) {
                            return ReportDetailHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('report-detail-history', null, { reload: true });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
