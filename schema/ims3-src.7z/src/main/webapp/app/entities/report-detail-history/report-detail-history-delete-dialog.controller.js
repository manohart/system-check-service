(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('ReportDetailHistoryDeleteController',ReportDetailHistoryDeleteController);

    ReportDetailHistoryDeleteController.$inject = ['$uibModalInstance', 'entity', 'ReportDetailHistory'];

    function ReportDetailHistoryDeleteController($uibModalInstance, entity, ReportDetailHistory) {
        var vm = this;

        vm.reportDetailHistory = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;
        
        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            ReportDetailHistory.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
