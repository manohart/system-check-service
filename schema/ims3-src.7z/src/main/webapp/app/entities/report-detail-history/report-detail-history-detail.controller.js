(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('ReportDetailHistoryDetailController', ReportDetailHistoryDetailController);

    ReportDetailHistoryDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'entity', 'ReportDetailHistory', 'DbNamedSql', 'ReportHistory'];

    function ReportDetailHistoryDetailController($scope, $rootScope, $stateParams, entity, ReportDetailHistory, DbNamedSql, ReportHistory) {
        var vm = this;

        vm.reportDetailHistory = entity;

        var unsubscribe = $rootScope.$on('imsApp:reportDetailHistoryUpdate', function(event, result) {
            vm.reportDetailHistory = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
