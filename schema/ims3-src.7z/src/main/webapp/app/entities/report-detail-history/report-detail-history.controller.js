(function() {
    'use strict';

    angular
        .module('imsApp')
        .controller('ReportDetailHistoryController', ReportDetailHistoryController);

    ReportDetailHistoryController.$inject = ['$scope', '$state', 'ReportDetailHistory'];

    function ReportDetailHistoryController ($scope, $state, ReportDetailHistory) {
        var vm = this;
        
        vm.reportDetailHistories = [];

        loadAll();

        function loadAll() {
            ReportDetailHistory.query(function(result) {
                vm.reportDetailHistories = result;
            });
        }
    }
})();
