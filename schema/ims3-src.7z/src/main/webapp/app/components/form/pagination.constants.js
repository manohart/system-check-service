(function() {
    'use strict';

    angular
        .module('imsApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
