package org.mano.ims.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A ReportDistribution.
 */
@Entity
@Table(name = "report_distribution")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class ReportDistribution implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "name")
    private String name;

    @NotNull
    @Column(name = "skip_empty_report", nullable = false)
    private String skipEmptyReport;

    @NotNull
    @Column(name = "is_active", nullable = false)
    private Boolean isActive;

    @ManyToOne
    private EmailConfig emailConfig;

    @ManyToOne
    private Report report;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSkipEmptyReport() {
        return skipEmptyReport;
    }

    public void setSkipEmptyReport(String skipEmptyReport) {
        this.skipEmptyReport = skipEmptyReport;
    }

    public Boolean isIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public EmailConfig getEmailConfig() {
        return emailConfig;
    }

    public void setEmailConfig(EmailConfig emailConfig) {
        this.emailConfig = emailConfig;
    }

    public Report getReport() {
        return report;
    }

    public void setReport(Report report) {
        this.report = report;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ReportDistribution reportDistribution = (ReportDistribution) o;
        if(reportDistribution.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, reportDistribution.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "ReportDistribution{" +
            "id=" + id +
            ", name='" + name + "'" +
            ", skipEmptyReport='" + skipEmptyReport + "'" +
            ", isActive='" + isActive + "'" +
            '}';
    }
}
