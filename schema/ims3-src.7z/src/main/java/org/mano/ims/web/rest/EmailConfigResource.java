package org.mano.ims.web.rest;

import com.codahale.metrics.annotation.Timed;
import org.mano.ims.domain.EmailConfig;
import org.mano.ims.repository.EmailConfigRepository;
import org.mano.ims.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing EmailConfig.
 */
@RestController
@RequestMapping("/api")
public class EmailConfigResource {

    private final Logger log = LoggerFactory.getLogger(EmailConfigResource.class);
        
    @Inject
    private EmailConfigRepository emailConfigRepository;
    
    /**
     * POST  /email-configs : Create a new emailConfig.
     *
     * @param emailConfig the emailConfig to create
     * @return the ResponseEntity with status 201 (Created) and with body the new emailConfig, or with status 400 (Bad Request) if the emailConfig has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/email-configs",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<EmailConfig> createEmailConfig(@Valid @RequestBody EmailConfig emailConfig) throws URISyntaxException {
        log.debug("REST request to save EmailConfig : {}", emailConfig);
        if (emailConfig.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("emailConfig", "idexists", "A new emailConfig cannot already have an ID")).body(null);
        }
        EmailConfig result = emailConfigRepository.save(emailConfig);
        return ResponseEntity.created(new URI("/api/email-configs/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("emailConfig", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /email-configs : Updates an existing emailConfig.
     *
     * @param emailConfig the emailConfig to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated emailConfig,
     * or with status 400 (Bad Request) if the emailConfig is not valid,
     * or with status 500 (Internal Server Error) if the emailConfig couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/email-configs",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<EmailConfig> updateEmailConfig(@Valid @RequestBody EmailConfig emailConfig) throws URISyntaxException {
        log.debug("REST request to update EmailConfig : {}", emailConfig);
        if (emailConfig.getId() == null) {
            return createEmailConfig(emailConfig);
        }
        EmailConfig result = emailConfigRepository.save(emailConfig);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("emailConfig", emailConfig.getId().toString()))
            .body(result);
    }

    /**
     * GET  /email-configs : get all the emailConfigs.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of emailConfigs in body
     */
    @RequestMapping(value = "/email-configs",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<EmailConfig> getAllEmailConfigs() {
        log.debug("REST request to get all EmailConfigs");
        List<EmailConfig> emailConfigs = emailConfigRepository.findAll();
        return emailConfigs;
    }

    /**
     * GET  /email-configs/:id : get the "id" emailConfig.
     *
     * @param id the id of the emailConfig to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the emailConfig, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/email-configs/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<EmailConfig> getEmailConfig(@PathVariable Long id) {
        log.debug("REST request to get EmailConfig : {}", id);
        EmailConfig emailConfig = emailConfigRepository.findOne(id);
        return Optional.ofNullable(emailConfig)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /email-configs/:id : delete the "id" emailConfig.
     *
     * @param id the id of the emailConfig to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/email-configs/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteEmailConfig(@PathVariable Long id) {
        log.debug("REST request to delete EmailConfig : {}", id);
        emailConfigRepository.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("emailConfig", id.toString())).build();
    }

}
