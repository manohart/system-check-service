package org.mano.ims.web.rest;

import com.codahale.metrics.annotation.Timed;
import org.mano.ims.domain.ReportDetailHistory;
import org.mano.ims.repository.ReportDetailHistoryRepository;
import org.mano.ims.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing ReportDetailHistory.
 */
@RestController
@RequestMapping("/api")
public class ReportDetailHistoryResource {

    private final Logger log = LoggerFactory.getLogger(ReportDetailHistoryResource.class);
        
    @Inject
    private ReportDetailHistoryRepository reportDetailHistoryRepository;
    
    /**
     * POST  /report-detail-histories : Create a new reportDetailHistory.
     *
     * @param reportDetailHistory the reportDetailHistory to create
     * @return the ResponseEntity with status 201 (Created) and with body the new reportDetailHistory, or with status 400 (Bad Request) if the reportDetailHistory has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/report-detail-histories",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<ReportDetailHistory> createReportDetailHistory(@Valid @RequestBody ReportDetailHistory reportDetailHistory) throws URISyntaxException {
        log.debug("REST request to save ReportDetailHistory : {}", reportDetailHistory);
        if (reportDetailHistory.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("reportDetailHistory", "idexists", "A new reportDetailHistory cannot already have an ID")).body(null);
        }
        ReportDetailHistory result = reportDetailHistoryRepository.save(reportDetailHistory);
        return ResponseEntity.created(new URI("/api/report-detail-histories/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("reportDetailHistory", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /report-detail-histories : Updates an existing reportDetailHistory.
     *
     * @param reportDetailHistory the reportDetailHistory to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated reportDetailHistory,
     * or with status 400 (Bad Request) if the reportDetailHistory is not valid,
     * or with status 500 (Internal Server Error) if the reportDetailHistory couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/report-detail-histories",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<ReportDetailHistory> updateReportDetailHistory(@Valid @RequestBody ReportDetailHistory reportDetailHistory) throws URISyntaxException {
        log.debug("REST request to update ReportDetailHistory : {}", reportDetailHistory);
        if (reportDetailHistory.getId() == null) {
            return createReportDetailHistory(reportDetailHistory);
        }
        ReportDetailHistory result = reportDetailHistoryRepository.save(reportDetailHistory);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("reportDetailHistory", reportDetailHistory.getId().toString()))
            .body(result);
    }

    /**
     * GET  /report-detail-histories : get all the reportDetailHistories.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of reportDetailHistories in body
     */
    @RequestMapping(value = "/report-detail-histories",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<ReportDetailHistory> getAllReportDetailHistories() {
        log.debug("REST request to get all ReportDetailHistories");
        List<ReportDetailHistory> reportDetailHistories = reportDetailHistoryRepository.findAll();
        return reportDetailHistories;
    }

    /**
     * GET  /report-detail-histories/:id : get the "id" reportDetailHistory.
     *
     * @param id the id of the reportDetailHistory to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the reportDetailHistory, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/report-detail-histories/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<ReportDetailHistory> getReportDetailHistory(@PathVariable Long id) {
        log.debug("REST request to get ReportDetailHistory : {}", id);
        ReportDetailHistory reportDetailHistory = reportDetailHistoryRepository.findOne(id);
        return Optional.ofNullable(reportDetailHistory)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /report-detail-histories/:id : delete the "id" reportDetailHistory.
     *
     * @param id the id of the reportDetailHistory to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/report-detail-histories/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteReportDetailHistory(@PathVariable Long id) {
        log.debug("REST request to delete ReportDetailHistory : {}", id);
        reportDetailHistoryRepository.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("reportDetailHistory", id.toString())).build();
    }

}
