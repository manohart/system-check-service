/**
 * Spring Framework configuration files.
 */
package org.mano.ims.config;
