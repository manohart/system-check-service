package org.mano.ims.web.rest;

import com.codahale.metrics.annotation.Timed;
import org.mano.ims.domain.Lob;
import org.mano.ims.repository.LobRepository;
import org.mano.ims.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Lob.
 */
@RestController
@RequestMapping("/api")
public class LobResource {

    private final Logger log = LoggerFactory.getLogger(LobResource.class);
        
    @Inject
    private LobRepository lobRepository;
    
    /**
     * POST  /lobs : Create a new lob.
     *
     * @param lob the lob to create
     * @return the ResponseEntity with status 201 (Created) and with body the new lob, or with status 400 (Bad Request) if the lob has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/lobs",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Lob> createLob(@Valid @RequestBody Lob lob) throws URISyntaxException {
        log.debug("REST request to save Lob : {}", lob);
        if (lob.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("lob", "idexists", "A new lob cannot already have an ID")).body(null);
        }
        Lob result = lobRepository.save(lob);
        return ResponseEntity.created(new URI("/api/lobs/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("lob", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /lobs : Updates an existing lob.
     *
     * @param lob the lob to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated lob,
     * or with status 400 (Bad Request) if the lob is not valid,
     * or with status 500 (Internal Server Error) if the lob couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/lobs",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Lob> updateLob(@Valid @RequestBody Lob lob) throws URISyntaxException {
        log.debug("REST request to update Lob : {}", lob);
        if (lob.getId() == null) {
            return createLob(lob);
        }
        Lob result = lobRepository.save(lob);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("lob", lob.getId().toString()))
            .body(result);
    }

    /**
     * GET  /lobs : get all the lobs.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of lobs in body
     */
    @RequestMapping(value = "/lobs",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<Lob> getAllLobs() {
        log.debug("REST request to get all Lobs");
        List<Lob> lobs = lobRepository.findAll();
        return lobs;
    }

    /**
     * GET  /lobs/:id : get the "id" lob.
     *
     * @param id the id of the lob to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the lob, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/lobs/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Lob> getLob(@PathVariable Long id) {
        log.debug("REST request to get Lob : {}", id);
        Lob lob = lobRepository.findOne(id);
        return Optional.ofNullable(lob)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /lobs/:id : delete the "id" lob.
     *
     * @param id the id of the lob to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/lobs/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteLob(@PathVariable Long id) {
        log.debug("REST request to delete Lob : {}", id);
        lobRepository.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("lob", id.toString())).build();
    }

}
