package org.mano.ims.web.rest;

import com.codahale.metrics.annotation.Timed;
import org.mano.ims.domain.ReportDistribution;
import org.mano.ims.repository.ReportDistributionRepository;
import org.mano.ims.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing ReportDistribution.
 */
@RestController
@RequestMapping("/api")
public class ReportDistributionResource {

    private final Logger log = LoggerFactory.getLogger(ReportDistributionResource.class);
        
    @Inject
    private ReportDistributionRepository reportDistributionRepository;
    
    /**
     * POST  /report-distributions : Create a new reportDistribution.
     *
     * @param reportDistribution the reportDistribution to create
     * @return the ResponseEntity with status 201 (Created) and with body the new reportDistribution, or with status 400 (Bad Request) if the reportDistribution has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/report-distributions",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<ReportDistribution> createReportDistribution(@Valid @RequestBody ReportDistribution reportDistribution) throws URISyntaxException {
        log.debug("REST request to save ReportDistribution : {}", reportDistribution);
        if (reportDistribution.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("reportDistribution", "idexists", "A new reportDistribution cannot already have an ID")).body(null);
        }
        ReportDistribution result = reportDistributionRepository.save(reportDistribution);
        return ResponseEntity.created(new URI("/api/report-distributions/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("reportDistribution", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /report-distributions : Updates an existing reportDistribution.
     *
     * @param reportDistribution the reportDistribution to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated reportDistribution,
     * or with status 400 (Bad Request) if the reportDistribution is not valid,
     * or with status 500 (Internal Server Error) if the reportDistribution couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/report-distributions",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<ReportDistribution> updateReportDistribution(@Valid @RequestBody ReportDistribution reportDistribution) throws URISyntaxException {
        log.debug("REST request to update ReportDistribution : {}", reportDistribution);
        if (reportDistribution.getId() == null) {
            return createReportDistribution(reportDistribution);
        }
        ReportDistribution result = reportDistributionRepository.save(reportDistribution);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("reportDistribution", reportDistribution.getId().toString()))
            .body(result);
    }

    /**
     * GET  /report-distributions : get all the reportDistributions.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of reportDistributions in body
     */
    @RequestMapping(value = "/report-distributions",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<ReportDistribution> getAllReportDistributions() {
        log.debug("REST request to get all ReportDistributions");
        List<ReportDistribution> reportDistributions = reportDistributionRepository.findAll();
        return reportDistributions;
    }

    /**
     * GET  /report-distributions/:id : get the "id" reportDistribution.
     *
     * @param id the id of the reportDistribution to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the reportDistribution, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/report-distributions/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<ReportDistribution> getReportDistribution(@PathVariable Long id) {
        log.debug("REST request to get ReportDistribution : {}", id);
        ReportDistribution reportDistribution = reportDistributionRepository.findOne(id);
        return Optional.ofNullable(reportDistribution)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /report-distributions/:id : delete the "id" reportDistribution.
     *
     * @param id the id of the reportDistribution to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/report-distributions/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteReportDistribution(@PathVariable Long id) {
        log.debug("REST request to delete ReportDistribution : {}", id);
        reportDistributionRepository.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("reportDistribution", id.toString())).build();
    }

}
