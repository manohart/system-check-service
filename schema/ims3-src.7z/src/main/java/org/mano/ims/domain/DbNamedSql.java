package org.mano.ims.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A DbNamedSql.
 */
@Entity
@Table(name = "db_named_sql")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class DbNamedSql implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "namespace", nullable = false)
    private String namespace;

    @NotNull
    @Column(name = "statement_id", nullable = false)
    private String statementId;

    @NotNull
    @Column(name = "description", nullable = false)
    private String description;

    @OneToMany(mappedBy = "dbNamedSql")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<DbCheck> dbChecks = new HashSet<>();

    @OneToMany(mappedBy = "dbNamedSql")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<ReportDetailHistory> reportDetailHistories = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getStatementId() {
        return statementId;
    }

    public void setStatementId(String statementId) {
        this.statementId = statementId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Set<DbCheck> getDbChecks() {
        return dbChecks;
    }

    public void setDbChecks(Set<DbCheck> dbChecks) {
        this.dbChecks = dbChecks;
    }

    public Set<ReportDetailHistory> getReportDetailHistories() {
        return reportDetailHistories;
    }

    public void setReportDetailHistories(Set<ReportDetailHistory> reportDetailHistories) {
        this.reportDetailHistories = reportDetailHistories;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        DbNamedSql dbNamedSql = (DbNamedSql) o;
        if(dbNamedSql.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, dbNamedSql.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "DbNamedSql{" +
            "id=" + id +
            ", namespace='" + namespace + "'" +
            ", statementId='" + statementId + "'" +
            ", description='" + description + "'" +
            '}';
    }
}
