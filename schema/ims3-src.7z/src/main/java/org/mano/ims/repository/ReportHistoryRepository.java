package org.mano.ims.repository;

import org.mano.ims.domain.ReportHistory;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the ReportHistory entity.
 */
@SuppressWarnings("unused")
public interface ReportHistoryRepository extends JpaRepository<ReportHistory,Long> {

}
