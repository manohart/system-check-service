package org.mano.ims.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A Lob.
 */
@Entity
@Table(name = "lob")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Lob implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "name", nullable = false)
    private String name;

    @NotNull
    @Column(name = "region", nullable = false)
    private String region;

    @NotNull
    @Column(name = "owner_email_id", nullable = false)
    private String ownerEmailId;

    @NotNull
    @Column(name = "lead_email_id", nullable = false)
    private String leadEmailId;

    @NotNull
    @Column(name = "report_archive_folder", nullable = false)
    private String reportArchiveFolder;

    @NotNull
    @Column(name = "sla", nullable = false)
    private String sla;

    @OneToMany(mappedBy = "lob")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Job> jobs = new HashSet<>();

    @ManyToOne
    private EmailConfig emailConfig;

    @ManyToOne
    private Template template;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getOwnerEmailId() {
        return ownerEmailId;
    }

    public void setOwnerEmailId(String ownerEmailId) {
        this.ownerEmailId = ownerEmailId;
    }

    public String getLeadEmailId() {
        return leadEmailId;
    }

    public void setLeadEmailId(String leadEmailId) {
        this.leadEmailId = leadEmailId;
    }

    public String getReportArchiveFolder() {
        return reportArchiveFolder;
    }

    public void setReportArchiveFolder(String reportArchiveFolder) {
        this.reportArchiveFolder = reportArchiveFolder;
    }

    public String getSla() {
        return sla;
    }

    public void setSla(String sla) {
        this.sla = sla;
    }

    public Set<Job> getJobs() {
        return jobs;
    }

    public void setJobs(Set<Job> jobs) {
        this.jobs = jobs;
    }

    public EmailConfig getEmailConfig() {
        return emailConfig;
    }

    public void setEmailConfig(EmailConfig emailConfig) {
        this.emailConfig = emailConfig;
    }

    public Template getTemplate() {
        return template;
    }

    public void setTemplate(Template template) {
        this.template = template;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Lob lob = (Lob) o;
        if(lob.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, lob.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Lob{" +
            "id=" + id +
            ", name='" + name + "'" +
            ", region='" + region + "'" +
            ", ownerEmailId='" + ownerEmailId + "'" +
            ", leadEmailId='" + leadEmailId + "'" +
            ", reportArchiveFolder='" + reportArchiveFolder + "'" +
            ", sla='" + sla + "'" +
            '}';
    }
}
