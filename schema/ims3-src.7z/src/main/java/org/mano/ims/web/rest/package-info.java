/**
 * Spring MVC REST controllers.
 */
package org.mano.ims.web.rest;
