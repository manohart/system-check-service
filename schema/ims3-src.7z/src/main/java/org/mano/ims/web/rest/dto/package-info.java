/**
 * Data Transfer Objects used by Spring MVC REST controllers.
 */
package org.mano.ims.web.rest.dto;
