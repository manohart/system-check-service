package org.mano.ims.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A Upstream.
 */
@Entity
@Table(name = "upstream")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Upstream implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "name", nullable = false)
    private String name;

    @NotNull
    @Column(name = "owner_email_id", nullable = false)
    private String ownerEmailId;

    @NotNull
    @Column(name = "team_dl_email_id", nullable = false)
    private String teamDlEmailId;

    @OneToMany(mappedBy = "upstream")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<DbCheck> dbChecks = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOwnerEmailId() {
        return ownerEmailId;
    }

    public void setOwnerEmailId(String ownerEmailId) {
        this.ownerEmailId = ownerEmailId;
    }

    public String getTeamDlEmailId() {
        return teamDlEmailId;
    }

    public void setTeamDlEmailId(String teamDlEmailId) {
        this.teamDlEmailId = teamDlEmailId;
    }

    public Set<DbCheck> getDbChecks() {
        return dbChecks;
    }

    public void setDbChecks(Set<DbCheck> dbChecks) {
        this.dbChecks = dbChecks;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Upstream upstream = (Upstream) o;
        if(upstream.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, upstream.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Upstream{" +
            "id=" + id +
            ", name='" + name + "'" +
            ", ownerEmailId='" + ownerEmailId + "'" +
            ", teamDlEmailId='" + teamDlEmailId + "'" +
            '}';
    }
}
