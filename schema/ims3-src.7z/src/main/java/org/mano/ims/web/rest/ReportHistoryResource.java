package org.mano.ims.web.rest;

import com.codahale.metrics.annotation.Timed;
import org.mano.ims.domain.ReportHistory;
import org.mano.ims.repository.ReportHistoryRepository;
import org.mano.ims.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing ReportHistory.
 */
@RestController
@RequestMapping("/api")
public class ReportHistoryResource {

    private final Logger log = LoggerFactory.getLogger(ReportHistoryResource.class);
        
    @Inject
    private ReportHistoryRepository reportHistoryRepository;
    
    /**
     * POST  /report-histories : Create a new reportHistory.
     *
     * @param reportHistory the reportHistory to create
     * @return the ResponseEntity with status 201 (Created) and with body the new reportHistory, or with status 400 (Bad Request) if the reportHistory has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/report-histories",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<ReportHistory> createReportHistory(@Valid @RequestBody ReportHistory reportHistory) throws URISyntaxException {
        log.debug("REST request to save ReportHistory : {}", reportHistory);
        if (reportHistory.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("reportHistory", "idexists", "A new reportHistory cannot already have an ID")).body(null);
        }
        ReportHistory result = reportHistoryRepository.save(reportHistory);
        return ResponseEntity.created(new URI("/api/report-histories/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("reportHistory", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /report-histories : Updates an existing reportHistory.
     *
     * @param reportHistory the reportHistory to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated reportHistory,
     * or with status 400 (Bad Request) if the reportHistory is not valid,
     * or with status 500 (Internal Server Error) if the reportHistory couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/report-histories",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<ReportHistory> updateReportHistory(@Valid @RequestBody ReportHistory reportHistory) throws URISyntaxException {
        log.debug("REST request to update ReportHistory : {}", reportHistory);
        if (reportHistory.getId() == null) {
            return createReportHistory(reportHistory);
        }
        ReportHistory result = reportHistoryRepository.save(reportHistory);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("reportHistory", reportHistory.getId().toString()))
            .body(result);
    }

    /**
     * GET  /report-histories : get all the reportHistories.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of reportHistories in body
     */
    @RequestMapping(value = "/report-histories",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<ReportHistory> getAllReportHistories() {
        log.debug("REST request to get all ReportHistories");
        List<ReportHistory> reportHistories = reportHistoryRepository.findAll();
        return reportHistories;
    }

    /**
     * GET  /report-histories/:id : get the "id" reportHistory.
     *
     * @param id the id of the reportHistory to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the reportHistory, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/report-histories/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<ReportHistory> getReportHistory(@PathVariable Long id) {
        log.debug("REST request to get ReportHistory : {}", id);
        ReportHistory reportHistory = reportHistoryRepository.findOne(id);
        return Optional.ofNullable(reportHistory)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /report-histories/:id : delete the "id" reportHistory.
     *
     * @param id the id of the reportHistory to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/report-histories/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteReportHistory(@PathVariable Long id) {
        log.debug("REST request to delete ReportHistory : {}", id);
        reportHistoryRepository.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("reportHistory", id.toString())).build();
    }

}
