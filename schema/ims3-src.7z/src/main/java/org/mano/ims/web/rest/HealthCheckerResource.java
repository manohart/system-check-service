package org.mano.ims.web.rest;

import com.codahale.metrics.annotation.Timed;
import org.mano.ims.domain.HealthChecker;
import org.mano.ims.repository.HealthCheckerRepository;
import org.mano.ims.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing HealthChecker.
 */
@RestController
@RequestMapping("/api")
public class HealthCheckerResource {

    private final Logger log = LoggerFactory.getLogger(HealthCheckerResource.class);
        
    @Inject
    private HealthCheckerRepository healthCheckerRepository;
    
    /**
     * POST  /health-checkers : Create a new healthChecker.
     *
     * @param healthChecker the healthChecker to create
     * @return the ResponseEntity with status 201 (Created) and with body the new healthChecker, or with status 400 (Bad Request) if the healthChecker has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/health-checkers",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<HealthChecker> createHealthChecker(@Valid @RequestBody HealthChecker healthChecker) throws URISyntaxException {
        log.debug("REST request to save HealthChecker : {}", healthChecker);
        if (healthChecker.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("healthChecker", "idexists", "A new healthChecker cannot already have an ID")).body(null);
        }
        HealthChecker result = healthCheckerRepository.save(healthChecker);
        return ResponseEntity.created(new URI("/api/health-checkers/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("healthChecker", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /health-checkers : Updates an existing healthChecker.
     *
     * @param healthChecker the healthChecker to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated healthChecker,
     * or with status 400 (Bad Request) if the healthChecker is not valid,
     * or with status 500 (Internal Server Error) if the healthChecker couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/health-checkers",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<HealthChecker> updateHealthChecker(@Valid @RequestBody HealthChecker healthChecker) throws URISyntaxException {
        log.debug("REST request to update HealthChecker : {}", healthChecker);
        if (healthChecker.getId() == null) {
            return createHealthChecker(healthChecker);
        }
        HealthChecker result = healthCheckerRepository.save(healthChecker);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("healthChecker", healthChecker.getId().toString()))
            .body(result);
    }

    /**
     * GET  /health-checkers : get all the healthCheckers.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of healthCheckers in body
     */
    @RequestMapping(value = "/health-checkers",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<HealthChecker> getAllHealthCheckers() {
        log.debug("REST request to get all HealthCheckers");
        List<HealthChecker> healthCheckers = healthCheckerRepository.findAll();
        return healthCheckers;
    }

    /**
     * GET  /health-checkers/:id : get the "id" healthChecker.
     *
     * @param id the id of the healthChecker to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the healthChecker, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/health-checkers/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<HealthChecker> getHealthChecker(@PathVariable Long id) {
        log.debug("REST request to get HealthChecker : {}", id);
        HealthChecker healthChecker = healthCheckerRepository.findOne(id);
        return Optional.ofNullable(healthChecker)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /health-checkers/:id : delete the "id" healthChecker.
     *
     * @param id the id of the healthChecker to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/health-checkers/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteHealthChecker(@PathVariable Long id) {
        log.debug("REST request to delete HealthChecker : {}", id);
        healthCheckerRepository.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("healthChecker", id.toString())).build();
    }

}
