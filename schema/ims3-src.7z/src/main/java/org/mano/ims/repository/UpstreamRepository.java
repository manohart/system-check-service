package org.mano.ims.repository;

import org.mano.ims.domain.Upstream;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the Upstream entity.
 */
@SuppressWarnings("unused")
public interface UpstreamRepository extends JpaRepository<Upstream,Long> {

}
