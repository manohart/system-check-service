package org.mano.ims.web.rest;

import com.codahale.metrics.annotation.Timed;
import org.mano.ims.domain.DbNamedSql;
import org.mano.ims.repository.DbNamedSqlRepository;
import org.mano.ims.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing DbNamedSql.
 */
@RestController
@RequestMapping("/api")
public class DbNamedSqlResource {

    private final Logger log = LoggerFactory.getLogger(DbNamedSqlResource.class);
        
    @Inject
    private DbNamedSqlRepository dbNamedSqlRepository;
    
    /**
     * POST  /db-named-sqls : Create a new dbNamedSql.
     *
     * @param dbNamedSql the dbNamedSql to create
     * @return the ResponseEntity with status 201 (Created) and with body the new dbNamedSql, or with status 400 (Bad Request) if the dbNamedSql has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/db-named-sqls",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<DbNamedSql> createDbNamedSql(@Valid @RequestBody DbNamedSql dbNamedSql) throws URISyntaxException {
        log.debug("REST request to save DbNamedSql : {}", dbNamedSql);
        if (dbNamedSql.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("dbNamedSql", "idexists", "A new dbNamedSql cannot already have an ID")).body(null);
        }
        DbNamedSql result = dbNamedSqlRepository.save(dbNamedSql);
        return ResponseEntity.created(new URI("/api/db-named-sqls/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("dbNamedSql", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /db-named-sqls : Updates an existing dbNamedSql.
     *
     * @param dbNamedSql the dbNamedSql to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated dbNamedSql,
     * or with status 400 (Bad Request) if the dbNamedSql is not valid,
     * or with status 500 (Internal Server Error) if the dbNamedSql couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/db-named-sqls",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<DbNamedSql> updateDbNamedSql(@Valid @RequestBody DbNamedSql dbNamedSql) throws URISyntaxException {
        log.debug("REST request to update DbNamedSql : {}", dbNamedSql);
        if (dbNamedSql.getId() == null) {
            return createDbNamedSql(dbNamedSql);
        }
        DbNamedSql result = dbNamedSqlRepository.save(dbNamedSql);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("dbNamedSql", dbNamedSql.getId().toString()))
            .body(result);
    }

    /**
     * GET  /db-named-sqls : get all the dbNamedSqls.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of dbNamedSqls in body
     */
    @RequestMapping(value = "/db-named-sqls",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<DbNamedSql> getAllDbNamedSqls() {
        log.debug("REST request to get all DbNamedSqls");
        List<DbNamedSql> dbNamedSqls = dbNamedSqlRepository.findAll();
        return dbNamedSqls;
    }

    /**
     * GET  /db-named-sqls/:id : get the "id" dbNamedSql.
     *
     * @param id the id of the dbNamedSql to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the dbNamedSql, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/db-named-sqls/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<DbNamedSql> getDbNamedSql(@PathVariable Long id) {
        log.debug("REST request to get DbNamedSql : {}", id);
        DbNamedSql dbNamedSql = dbNamedSqlRepository.findOne(id);
        return Optional.ofNullable(dbNamedSql)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /db-named-sqls/:id : delete the "id" dbNamedSql.
     *
     * @param id the id of the dbNamedSql to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/db-named-sqls/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteDbNamedSql(@PathVariable Long id) {
        log.debug("REST request to delete DbNamedSql : {}", id);
        dbNamedSqlRepository.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("dbNamedSql", id.toString())).build();
    }

}
