/**
 * Audit specific code.
 */
package org.mano.ims.config.audit;
