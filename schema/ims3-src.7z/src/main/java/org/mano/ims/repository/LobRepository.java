package org.mano.ims.repository;

import org.mano.ims.domain.Lob;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the Lob entity.
 */
@SuppressWarnings("unused")
public interface LobRepository extends JpaRepository<Lob,Long> {

}
