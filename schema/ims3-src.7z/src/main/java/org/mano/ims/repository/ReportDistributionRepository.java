package org.mano.ims.repository;

import org.mano.ims.domain.ReportDistribution;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the ReportDistribution entity.
 */
@SuppressWarnings("unused")
public interface ReportDistributionRepository extends JpaRepository<ReportDistribution,Long> {

}
