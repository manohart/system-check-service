/**
 * JPA domain objects.
 */
package org.mano.ims.domain;
