/**
 * Spring Security configuration.
 */
package org.mano.ims.security;
