package org.mano.ims.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DbCheck.
 */
@Entity
@Table(name = "db_check")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class DbCheck implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "name")
    private String name;

    @NotNull
    @Column(name = "sequence", nullable = false)
    private Integer sequence;

    @Column(name = "query_input")
    private String queryInput;

    @NotNull
    @Column(name = "expectation", nullable = false)
    private String expectation;

    @NotNull
    @Column(name = "report_issues_only", nullable = false)
    private String reportIssuesOnly;

    @Column(name = "group_columns")
    private String groupColumns;

    @Column(name = "run_book_link")
    private String runBookLink;

    @Column(name = "is_active")
    private Boolean isActive;

    @ManyToOne
    private HealthChecker healthChecker;

    @ManyToOne
    private Report report;

    @ManyToOne
    private DbNamedSql dbNamedSql;

    @ManyToOne
    private Upstream upstream;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public String getQueryInput() {
        return queryInput;
    }

    public void setQueryInput(String queryInput) {
        this.queryInput = queryInput;
    }

    public String getExpectation() {
        return expectation;
    }

    public void setExpectation(String expectation) {
        this.expectation = expectation;
    }

    public String getReportIssuesOnly() {
        return reportIssuesOnly;
    }

    public void setReportIssuesOnly(String reportIssuesOnly) {
        this.reportIssuesOnly = reportIssuesOnly;
    }

    public String getGroupColumns() {
        return groupColumns;
    }

    public void setGroupColumns(String groupColumns) {
        this.groupColumns = groupColumns;
    }

    public String getRunBookLink() {
        return runBookLink;
    }

    public void setRunBookLink(String runBookLink) {
        this.runBookLink = runBookLink;
    }

    public Boolean isIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public HealthChecker getHealthChecker() {
        return healthChecker;
    }

    public void setHealthChecker(HealthChecker healthChecker) {
        this.healthChecker = healthChecker;
    }

    public Report getReport() {
        return report;
    }

    public void setReport(Report report) {
        this.report = report;
    }

    public DbNamedSql getDbNamedSql() {
        return dbNamedSql;
    }

    public void setDbNamedSql(DbNamedSql dbNamedSql) {
        this.dbNamedSql = dbNamedSql;
    }

    public Upstream getUpstream() {
        return upstream;
    }

    public void setUpstream(Upstream upstream) {
        this.upstream = upstream;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        DbCheck dbCheck = (DbCheck) o;
        if(dbCheck.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, dbCheck.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "DbCheck{" +
            "id=" + id +
            ", name='" + name + "'" +
            ", sequence='" + sequence + "'" +
            ", queryInput='" + queryInput + "'" +
            ", expectation='" + expectation + "'" +
            ", reportIssuesOnly='" + reportIssuesOnly + "'" +
            ", groupColumns='" + groupColumns + "'" +
            ", runBookLink='" + runBookLink + "'" +
            ", isActive='" + isActive + "'" +
            '}';
    }
}
