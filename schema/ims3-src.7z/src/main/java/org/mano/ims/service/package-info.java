/**
 * Service layer beans.
 */
package org.mano.ims.service;
