package org.mano.ims.repository;

import org.mano.ims.domain.ReportDetailHistory;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the ReportDetailHistory entity.
 */
@SuppressWarnings("unused")
public interface ReportDetailHistoryRepository extends JpaRepository<ReportDetailHistory,Long> {

}
