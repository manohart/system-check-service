/**
 * Locale specific code.
 */
package org.mano.ims.config.locale;
