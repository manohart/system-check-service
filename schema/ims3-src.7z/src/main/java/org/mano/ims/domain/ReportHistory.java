package org.mano.ims.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A ReportHistory.
 */
@Entity
@Table(name = "report_history")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class ReportHistory implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "initial_status", nullable = false)
    private String initialStatus;

    @NotNull
    @Column(name = "final_status", nullable = false)
    private String finalStatus;

    @NotNull
    @Column(name = "business_date", nullable = false)
    private LocalDate businessDate;

    @Column(name = "comment")
    private String comment;

    @ManyToOne
    private Report report;

    @OneToMany(mappedBy = "reportHistory")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<ReportDetailHistory> reportDetailHistories = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getInitialStatus() {
        return initialStatus;
    }

    public void setInitialStatus(String initialStatus) {
        this.initialStatus = initialStatus;
    }

    public String getFinalStatus() {
        return finalStatus;
    }

    public void setFinalStatus(String finalStatus) {
        this.finalStatus = finalStatus;
    }

    public LocalDate getBusinessDate() {
        return businessDate;
    }

    public void setBusinessDate(LocalDate businessDate) {
        this.businessDate = businessDate;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Report getReport() {
        return report;
    }

    public void setReport(Report report) {
        this.report = report;
    }

    public Set<ReportDetailHistory> getReportDetailHistories() {
        return reportDetailHistories;
    }

    public void setReportDetailHistories(Set<ReportDetailHistory> reportDetailHistories) {
        this.reportDetailHistories = reportDetailHistories;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ReportHistory reportHistory = (ReportHistory) o;
        if(reportHistory.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, reportHistory.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "ReportHistory{" +
            "id=" + id +
            ", initialStatus='" + initialStatus + "'" +
            ", finalStatus='" + finalStatus + "'" +
            ", businessDate='" + businessDate + "'" +
            ", comment='" + comment + "'" +
            '}';
    }
}
