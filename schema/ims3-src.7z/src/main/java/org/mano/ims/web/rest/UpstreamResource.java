package org.mano.ims.web.rest;

import com.codahale.metrics.annotation.Timed;
import org.mano.ims.domain.Upstream;
import org.mano.ims.repository.UpstreamRepository;
import org.mano.ims.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Upstream.
 */
@RestController
@RequestMapping("/api")
public class UpstreamResource {

    private final Logger log = LoggerFactory.getLogger(UpstreamResource.class);
        
    @Inject
    private UpstreamRepository upstreamRepository;
    
    /**
     * POST  /upstreams : Create a new upstream.
     *
     * @param upstream the upstream to create
     * @return the ResponseEntity with status 201 (Created) and with body the new upstream, or with status 400 (Bad Request) if the upstream has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/upstreams",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Upstream> createUpstream(@Valid @RequestBody Upstream upstream) throws URISyntaxException {
        log.debug("REST request to save Upstream : {}", upstream);
        if (upstream.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("upstream", "idexists", "A new upstream cannot already have an ID")).body(null);
        }
        Upstream result = upstreamRepository.save(upstream);
        return ResponseEntity.created(new URI("/api/upstreams/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("upstream", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /upstreams : Updates an existing upstream.
     *
     * @param upstream the upstream to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated upstream,
     * or with status 400 (Bad Request) if the upstream is not valid,
     * or with status 500 (Internal Server Error) if the upstream couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/upstreams",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Upstream> updateUpstream(@Valid @RequestBody Upstream upstream) throws URISyntaxException {
        log.debug("REST request to update Upstream : {}", upstream);
        if (upstream.getId() == null) {
            return createUpstream(upstream);
        }
        Upstream result = upstreamRepository.save(upstream);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("upstream", upstream.getId().toString()))
            .body(result);
    }

    /**
     * GET  /upstreams : get all the upstreams.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of upstreams in body
     */
    @RequestMapping(value = "/upstreams",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<Upstream> getAllUpstreams() {
        log.debug("REST request to get all Upstreams");
        List<Upstream> upstreams = upstreamRepository.findAll();
        return upstreams;
    }

    /**
     * GET  /upstreams/:id : get the "id" upstream.
     *
     * @param id the id of the upstream to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the upstream, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/upstreams/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Upstream> getUpstream(@PathVariable Long id) {
        log.debug("REST request to get Upstream : {}", id);
        Upstream upstream = upstreamRepository.findOne(id);
        return Optional.ofNullable(upstream)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /upstreams/:id : delete the "id" upstream.
     *
     * @param id the id of the upstream to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/upstreams/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteUpstream(@PathVariable Long id) {
        log.debug("REST request to delete Upstream : {}", id);
        upstreamRepository.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("upstream", id.toString())).build();
    }

}
