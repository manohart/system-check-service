/**
 * Async helpers.
 */
package org.mano.ims.async;
