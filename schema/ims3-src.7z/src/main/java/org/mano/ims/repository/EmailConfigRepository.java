package org.mano.ims.repository;

import org.mano.ims.domain.EmailConfig;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the EmailConfig entity.
 */
@SuppressWarnings("unused")
public interface EmailConfigRepository extends JpaRepository<EmailConfig,Long> {

}
