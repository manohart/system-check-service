package org.mano.ims.repository;

import org.mano.ims.domain.DbNamedSql;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the DbNamedSql entity.
 */
@SuppressWarnings("unused")
public interface DbNamedSqlRepository extends JpaRepository<DbNamedSql,Long> {

}
