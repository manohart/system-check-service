/**
 * Swagger api specific code.
 */
package org.mano.ims.config.apidoc;