package org.mano.ims.web.rest;

import com.codahale.metrics.annotation.Timed;
import org.mano.ims.domain.DbCheck;
import org.mano.ims.repository.DbCheckRepository;
import org.mano.ims.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing DbCheck.
 */
@RestController
@RequestMapping("/api")
public class DbCheckResource {

    private final Logger log = LoggerFactory.getLogger(DbCheckResource.class);
        
    @Inject
    private DbCheckRepository dbCheckRepository;
    
    /**
     * POST  /db-checks : Create a new dbCheck.
     *
     * @param dbCheck the dbCheck to create
     * @return the ResponseEntity with status 201 (Created) and with body the new dbCheck, or with status 400 (Bad Request) if the dbCheck has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/db-checks",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<DbCheck> createDbCheck(@Valid @RequestBody DbCheck dbCheck) throws URISyntaxException {
        log.debug("REST request to save DbCheck : {}", dbCheck);
        if (dbCheck.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("dbCheck", "idexists", "A new dbCheck cannot already have an ID")).body(null);
        }
        DbCheck result = dbCheckRepository.save(dbCheck);
        return ResponseEntity.created(new URI("/api/db-checks/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("dbCheck", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /db-checks : Updates an existing dbCheck.
     *
     * @param dbCheck the dbCheck to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated dbCheck,
     * or with status 400 (Bad Request) if the dbCheck is not valid,
     * or with status 500 (Internal Server Error) if the dbCheck couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/db-checks",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<DbCheck> updateDbCheck(@Valid @RequestBody DbCheck dbCheck) throws URISyntaxException {
        log.debug("REST request to update DbCheck : {}", dbCheck);
        if (dbCheck.getId() == null) {
            return createDbCheck(dbCheck);
        }
        DbCheck result = dbCheckRepository.save(dbCheck);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("dbCheck", dbCheck.getId().toString()))
            .body(result);
    }

    /**
     * GET  /db-checks : get all the dbChecks.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of dbChecks in body
     */
    @RequestMapping(value = "/db-checks",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<DbCheck> getAllDbChecks() {
        log.debug("REST request to get all DbChecks");
        List<DbCheck> dbChecks = dbCheckRepository.findAll();
        return dbChecks;
    }

    /**
     * GET  /db-checks/:id : get the "id" dbCheck.
     *
     * @param id the id of the dbCheck to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the dbCheck, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/db-checks/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<DbCheck> getDbCheck(@PathVariable Long id) {
        log.debug("REST request to get DbCheck : {}", id);
        DbCheck dbCheck = dbCheckRepository.findOne(id);
        return Optional.ofNullable(dbCheck)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /db-checks/:id : delete the "id" dbCheck.
     *
     * @param id the id of the dbCheck to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/db-checks/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteDbCheck(@PathVariable Long id) {
        log.debug("REST request to delete DbCheck : {}", id);
        dbCheckRepository.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("dbCheck", id.toString())).build();
    }

}
