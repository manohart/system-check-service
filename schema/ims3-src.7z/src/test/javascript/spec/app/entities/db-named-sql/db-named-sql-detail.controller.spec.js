'use strict';

describe('Controller Tests', function() {

    describe('DbNamedSql Management Detail Controller', function() {
        var $scope, $rootScope;
        var MockEntity, MockDbNamedSql, MockDbCheck, MockReportDetailHistory;
        var createController;

        beforeEach(inject(function($injector) {
            $rootScope = $injector.get('$rootScope');
            $scope = $rootScope.$new();
            MockEntity = jasmine.createSpy('MockEntity');
            MockDbNamedSql = jasmine.createSpy('MockDbNamedSql');
            MockDbCheck = jasmine.createSpy('MockDbCheck');
            MockReportDetailHistory = jasmine.createSpy('MockReportDetailHistory');
            

            var locals = {
                '$scope': $scope,
                '$rootScope': $rootScope,
                'entity': MockEntity ,
                'DbNamedSql': MockDbNamedSql,
                'DbCheck': MockDbCheck,
                'ReportDetailHistory': MockReportDetailHistory
            };
            createController = function() {
                $injector.get('$controller')("DbNamedSqlDetailController", locals);
            };
        }));


        describe('Root Scope Listening', function() {
            it('Unregisters root scope listener upon scope destruction', function() {
                var eventType = 'imsApp:dbNamedSqlUpdate';

                createController();
                expect($rootScope.$$listenerCount[eventType]).toEqual(1);

                $scope.$destroy();
                expect($rootScope.$$listenerCount[eventType]).toBeUndefined();
            });
        });
    });

});
