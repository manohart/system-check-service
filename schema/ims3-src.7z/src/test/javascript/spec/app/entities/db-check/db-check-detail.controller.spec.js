'use strict';

describe('Controller Tests', function() {

    describe('DbCheck Management Detail Controller', function() {
        var $scope, $rootScope;
        var MockEntity, MockDbCheck, MockHealthChecker, MockReport, MockDbNamedSql, MockUpstream;
        var createController;

        beforeEach(inject(function($injector) {
            $rootScope = $injector.get('$rootScope');
            $scope = $rootScope.$new();
            MockEntity = jasmine.createSpy('MockEntity');
            MockDbCheck = jasmine.createSpy('MockDbCheck');
            MockHealthChecker = jasmine.createSpy('MockHealthChecker');
            MockReport = jasmine.createSpy('MockReport');
            MockDbNamedSql = jasmine.createSpy('MockDbNamedSql');
            MockUpstream = jasmine.createSpy('MockUpstream');
            

            var locals = {
                '$scope': $scope,
                '$rootScope': $rootScope,
                'entity': MockEntity ,
                'DbCheck': MockDbCheck,
                'HealthChecker': MockHealthChecker,
                'Report': MockReport,
                'DbNamedSql': MockDbNamedSql,
                'Upstream': MockUpstream
            };
            createController = function() {
                $injector.get('$controller')("DbCheckDetailController", locals);
            };
        }));


        describe('Root Scope Listening', function() {
            it('Unregisters root scope listener upon scope destruction', function() {
                var eventType = 'imsApp:dbCheckUpdate';

                createController();
                expect($rootScope.$$listenerCount[eventType]).toEqual(1);

                $scope.$destroy();
                expect($rootScope.$$listenerCount[eventType]).toBeUndefined();
            });
        });
    });

});
