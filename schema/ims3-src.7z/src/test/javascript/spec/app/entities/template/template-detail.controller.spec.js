'use strict';

describe('Controller Tests', function() {

    describe('Template Management Detail Controller', function() {
        var $scope, $rootScope;
        var MockEntity, MockTemplate, MockLob;
        var createController;

        beforeEach(inject(function($injector) {
            $rootScope = $injector.get('$rootScope');
            $scope = $rootScope.$new();
            MockEntity = jasmine.createSpy('MockEntity');
            MockTemplate = jasmine.createSpy('MockTemplate');
            MockLob = jasmine.createSpy('MockLob');
            

            var locals = {
                '$scope': $scope,
                '$rootScope': $rootScope,
                'entity': MockEntity ,
                'Template': MockTemplate,
                'Lob': MockLob
            };
            createController = function() {
                $injector.get('$controller')("TemplateDetailController", locals);
            };
        }));


        describe('Root Scope Listening', function() {
            it('Unregisters root scope listener upon scope destruction', function() {
                var eventType = 'imsApp:templateUpdate';

                createController();
                expect($rootScope.$$listenerCount[eventType]).toEqual(1);

                $scope.$destroy();
                expect($rootScope.$$listenerCount[eventType]).toBeUndefined();
            });
        });
    });

});
