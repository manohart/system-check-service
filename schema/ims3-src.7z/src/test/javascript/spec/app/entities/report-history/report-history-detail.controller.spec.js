'use strict';

describe('Controller Tests', function() {

    describe('ReportHistory Management Detail Controller', function() {
        var $scope, $rootScope;
        var MockEntity, MockReportHistory, MockReport, MockReportDetailHistory;
        var createController;

        beforeEach(inject(function($injector) {
            $rootScope = $injector.get('$rootScope');
            $scope = $rootScope.$new();
            MockEntity = jasmine.createSpy('MockEntity');
            MockReportHistory = jasmine.createSpy('MockReportHistory');
            MockReport = jasmine.createSpy('MockReport');
            MockReportDetailHistory = jasmine.createSpy('MockReportDetailHistory');
            

            var locals = {
                '$scope': $scope,
                '$rootScope': $rootScope,
                'entity': MockEntity ,
                'ReportHistory': MockReportHistory,
                'Report': MockReport,
                'ReportDetailHistory': MockReportDetailHistory
            };
            createController = function() {
                $injector.get('$controller')("ReportHistoryDetailController", locals);
            };
        }));


        describe('Root Scope Listening', function() {
            it('Unregisters root scope listener upon scope destruction', function() {
                var eventType = 'imsApp:reportHistoryUpdate';

                createController();
                expect($rootScope.$$listenerCount[eventType]).toEqual(1);

                $scope.$destroy();
                expect($rootScope.$$listenerCount[eventType]).toBeUndefined();
            });
        });
    });

});
