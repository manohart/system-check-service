'use strict';

describe('Controller Tests', function() {

    describe('ReportDistribution Management Detail Controller', function() {
        var $scope, $rootScope;
        var MockEntity, MockReportDistribution, MockEmailConfig, MockReport;
        var createController;

        beforeEach(inject(function($injector) {
            $rootScope = $injector.get('$rootScope');
            $scope = $rootScope.$new();
            MockEntity = jasmine.createSpy('MockEntity');
            MockReportDistribution = jasmine.createSpy('MockReportDistribution');
            MockEmailConfig = jasmine.createSpy('MockEmailConfig');
            MockReport = jasmine.createSpy('MockReport');
            

            var locals = {
                '$scope': $scope,
                '$rootScope': $rootScope,
                'entity': MockEntity ,
                'ReportDistribution': MockReportDistribution,
                'EmailConfig': MockEmailConfig,
                'Report': MockReport
            };
            createController = function() {
                $injector.get('$controller')("ReportDistributionDetailController", locals);
            };
        }));


        describe('Root Scope Listening', function() {
            it('Unregisters root scope listener upon scope destruction', function() {
                var eventType = 'imsApp:reportDistributionUpdate';

                createController();
                expect($rootScope.$$listenerCount[eventType]).toEqual(1);

                $scope.$destroy();
                expect($rootScope.$$listenerCount[eventType]).toBeUndefined();
            });
        });
    });

});
