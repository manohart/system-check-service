'use strict';

describe('Controller Tests', function() {

    describe('HealthChecker Management Detail Controller', function() {
        var $scope, $rootScope;
        var MockEntity, MockHealthChecker, MockDbCheck;
        var createController;

        beforeEach(inject(function($injector) {
            $rootScope = $injector.get('$rootScope');
            $scope = $rootScope.$new();
            MockEntity = jasmine.createSpy('MockEntity');
            MockHealthChecker = jasmine.createSpy('MockHealthChecker');
            MockDbCheck = jasmine.createSpy('MockDbCheck');
            

            var locals = {
                '$scope': $scope,
                '$rootScope': $rootScope,
                'entity': MockEntity ,
                'HealthChecker': MockHealthChecker,
                'DbCheck': MockDbCheck
            };
            createController = function() {
                $injector.get('$controller')("HealthCheckerDetailController", locals);
            };
        }));


        describe('Root Scope Listening', function() {
            it('Unregisters root scope listener upon scope destruction', function() {
                var eventType = 'imsApp:healthCheckerUpdate';

                createController();
                expect($rootScope.$$listenerCount[eventType]).toEqual(1);

                $scope.$destroy();
                expect($rootScope.$$listenerCount[eventType]).toBeUndefined();
            });
        });
    });

});
