'use strict';

describe('Controller Tests', function() {

    describe('Upstream Management Detail Controller', function() {
        var $scope, $rootScope;
        var MockEntity, MockUpstream, MockDbCheck;
        var createController;

        beforeEach(inject(function($injector) {
            $rootScope = $injector.get('$rootScope');
            $scope = $rootScope.$new();
            MockEntity = jasmine.createSpy('MockEntity');
            MockUpstream = jasmine.createSpy('MockUpstream');
            MockDbCheck = jasmine.createSpy('MockDbCheck');
            

            var locals = {
                '$scope': $scope,
                '$rootScope': $rootScope,
                'entity': MockEntity ,
                'Upstream': MockUpstream,
                'DbCheck': MockDbCheck
            };
            createController = function() {
                $injector.get('$controller')("UpstreamDetailController", locals);
            };
        }));


        describe('Root Scope Listening', function() {
            it('Unregisters root scope listener upon scope destruction', function() {
                var eventType = 'imsApp:upstreamUpdate';

                createController();
                expect($rootScope.$$listenerCount[eventType]).toEqual(1);

                $scope.$destroy();
                expect($rootScope.$$listenerCount[eventType]).toBeUndefined();
            });
        });
    });

});
