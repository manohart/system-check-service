'use strict';

describe('Controller Tests', function() {

    describe('Lob Management Detail Controller', function() {
        var $scope, $rootScope;
        var MockEntity, MockLob, MockJob, MockEmailConfig, MockTemplate;
        var createController;

        beforeEach(inject(function($injector) {
            $rootScope = $injector.get('$rootScope');
            $scope = $rootScope.$new();
            MockEntity = jasmine.createSpy('MockEntity');
            MockLob = jasmine.createSpy('MockLob');
            MockJob = jasmine.createSpy('MockJob');
            MockEmailConfig = jasmine.createSpy('MockEmailConfig');
            MockTemplate = jasmine.createSpy('MockTemplate');
            

            var locals = {
                '$scope': $scope,
                '$rootScope': $rootScope,
                'entity': MockEntity ,
                'Lob': MockLob,
                'Job': MockJob,
                'EmailConfig': MockEmailConfig,
                'Template': MockTemplate
            };
            createController = function() {
                $injector.get('$controller')("LobDetailController", locals);
            };
        }));


        describe('Root Scope Listening', function() {
            it('Unregisters root scope listener upon scope destruction', function() {
                var eventType = 'imsApp:lobUpdate';

                createController();
                expect($rootScope.$$listenerCount[eventType]).toEqual(1);

                $scope.$destroy();
                expect($rootScope.$$listenerCount[eventType]).toBeUndefined();
            });
        });
    });

});
