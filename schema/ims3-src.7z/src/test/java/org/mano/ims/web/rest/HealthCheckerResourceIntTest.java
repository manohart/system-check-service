package org.mano.ims.web.rest;

import org.mano.ims.ImsApp;
import org.mano.ims.domain.HealthChecker;
import org.mano.ims.repository.HealthCheckerRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


/**
 * Test class for the HealthCheckerResource REST controller.
 *
 * @see HealthCheckerResource
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = ImsApp.class)
@WebAppConfiguration
@IntegrationTest
public class HealthCheckerResourceIntTest {

    private static final String DEFAULT_NAME = "AAAAA";
    private static final String UPDATED_NAME = "BBBBB";
    private static final String DEFAULT_JAVA_CLASS = "AAAAA";
    private static final String UPDATED_JAVA_CLASS = "BBBBB";

    @Inject
    private HealthCheckerRepository healthCheckerRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    private MockMvc restHealthCheckerMockMvc;

    private HealthChecker healthChecker;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        HealthCheckerResource healthCheckerResource = new HealthCheckerResource();
        ReflectionTestUtils.setField(healthCheckerResource, "healthCheckerRepository", healthCheckerRepository);
        this.restHealthCheckerMockMvc = MockMvcBuilders.standaloneSetup(healthCheckerResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    @Before
    public void initTest() {
        healthChecker = new HealthChecker();
        healthChecker.setName(DEFAULT_NAME);
        healthChecker.setJavaClass(DEFAULT_JAVA_CLASS);
    }

    @Test
    @Transactional
    public void createHealthChecker() throws Exception {
        int databaseSizeBeforeCreate = healthCheckerRepository.findAll().size();

        // Create the HealthChecker

        restHealthCheckerMockMvc.perform(post("/api/health-checkers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(healthChecker)))
                .andExpect(status().isCreated());

        // Validate the HealthChecker in the database
        List<HealthChecker> healthCheckers = healthCheckerRepository.findAll();
        assertThat(healthCheckers).hasSize(databaseSizeBeforeCreate + 1);
        HealthChecker testHealthChecker = healthCheckers.get(healthCheckers.size() - 1);
        assertThat(testHealthChecker.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testHealthChecker.getJavaClass()).isEqualTo(DEFAULT_JAVA_CLASS);
    }

    @Test
    @Transactional
    public void checkNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = healthCheckerRepository.findAll().size();
        // set the field null
        healthChecker.setName(null);

        // Create the HealthChecker, which fails.

        restHealthCheckerMockMvc.perform(post("/api/health-checkers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(healthChecker)))
                .andExpect(status().isBadRequest());

        List<HealthChecker> healthCheckers = healthCheckerRepository.findAll();
        assertThat(healthCheckers).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkJavaClassIsRequired() throws Exception {
        int databaseSizeBeforeTest = healthCheckerRepository.findAll().size();
        // set the field null
        healthChecker.setJavaClass(null);

        // Create the HealthChecker, which fails.

        restHealthCheckerMockMvc.perform(post("/api/health-checkers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(healthChecker)))
                .andExpect(status().isBadRequest());

        List<HealthChecker> healthCheckers = healthCheckerRepository.findAll();
        assertThat(healthCheckers).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllHealthCheckers() throws Exception {
        // Initialize the database
        healthCheckerRepository.saveAndFlush(healthChecker);

        // Get all the healthCheckers
        restHealthCheckerMockMvc.perform(get("/api/health-checkers?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.[*].id").value(hasItem(healthChecker.getId().intValue())))
                .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
                .andExpect(jsonPath("$.[*].javaClass").value(hasItem(DEFAULT_JAVA_CLASS.toString())));
    }

    @Test
    @Transactional
    public void getHealthChecker() throws Exception {
        // Initialize the database
        healthCheckerRepository.saveAndFlush(healthChecker);

        // Get the healthChecker
        restHealthCheckerMockMvc.perform(get("/api/health-checkers/{id}", healthChecker.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.id").value(healthChecker.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.javaClass").value(DEFAULT_JAVA_CLASS.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingHealthChecker() throws Exception {
        // Get the healthChecker
        restHealthCheckerMockMvc.perform(get("/api/health-checkers/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateHealthChecker() throws Exception {
        // Initialize the database
        healthCheckerRepository.saveAndFlush(healthChecker);
        int databaseSizeBeforeUpdate = healthCheckerRepository.findAll().size();

        // Update the healthChecker
        HealthChecker updatedHealthChecker = new HealthChecker();
        updatedHealthChecker.setId(healthChecker.getId());
        updatedHealthChecker.setName(UPDATED_NAME);
        updatedHealthChecker.setJavaClass(UPDATED_JAVA_CLASS);

        restHealthCheckerMockMvc.perform(put("/api/health-checkers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(updatedHealthChecker)))
                .andExpect(status().isOk());

        // Validate the HealthChecker in the database
        List<HealthChecker> healthCheckers = healthCheckerRepository.findAll();
        assertThat(healthCheckers).hasSize(databaseSizeBeforeUpdate);
        HealthChecker testHealthChecker = healthCheckers.get(healthCheckers.size() - 1);
        assertThat(testHealthChecker.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testHealthChecker.getJavaClass()).isEqualTo(UPDATED_JAVA_CLASS);
    }

    @Test
    @Transactional
    public void deleteHealthChecker() throws Exception {
        // Initialize the database
        healthCheckerRepository.saveAndFlush(healthChecker);
        int databaseSizeBeforeDelete = healthCheckerRepository.findAll().size();

        // Get the healthChecker
        restHealthCheckerMockMvc.perform(delete("/api/health-checkers/{id}", healthChecker.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate the database is empty
        List<HealthChecker> healthCheckers = healthCheckerRepository.findAll();
        assertThat(healthCheckers).hasSize(databaseSizeBeforeDelete - 1);
    }
}
