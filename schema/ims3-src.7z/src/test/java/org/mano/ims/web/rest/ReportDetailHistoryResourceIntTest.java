package org.mano.ims.web.rest;

import org.mano.ims.ImsApp;
import org.mano.ims.domain.ReportDetailHistory;
import org.mano.ims.repository.ReportDetailHistoryRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


/**
 * Test class for the ReportDetailHistoryResource REST controller.
 *
 * @see ReportDetailHistoryResource
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = ImsApp.class)
@WebAppConfiguration
@IntegrationTest
public class ReportDetailHistoryResourceIntTest {


    private static final Integer DEFAULT_RECORDS = 1;
    private static final Integer UPDATED_RECORDS = 2;

    private static final Integer DEFAULT_ISSUES = 1;
    private static final Integer UPDATED_ISSUES = 2;
    private static final String DEFAULT_INITIAL_STATUS = "AAAAA";
    private static final String UPDATED_INITIAL_STATUS = "BBBBB";
    private static final String DEFAULT_FINAL_STATUS = "AAAAA";
    private static final String UPDATED_FINAL_STATUS = "BBBBB";
    private static final String DEFAULT_COMMENT = "AAAAA";
    private static final String UPDATED_COMMENT = "BBBBB";

    @Inject
    private ReportDetailHistoryRepository reportDetailHistoryRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    private MockMvc restReportDetailHistoryMockMvc;

    private ReportDetailHistory reportDetailHistory;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        ReportDetailHistoryResource reportDetailHistoryResource = new ReportDetailHistoryResource();
        ReflectionTestUtils.setField(reportDetailHistoryResource, "reportDetailHistoryRepository", reportDetailHistoryRepository);
        this.restReportDetailHistoryMockMvc = MockMvcBuilders.standaloneSetup(reportDetailHistoryResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    @Before
    public void initTest() {
        reportDetailHistory = new ReportDetailHistory();
        reportDetailHistory.setRecords(DEFAULT_RECORDS);
        reportDetailHistory.setIssues(DEFAULT_ISSUES);
        reportDetailHistory.setInitialStatus(DEFAULT_INITIAL_STATUS);
        reportDetailHistory.setFinalStatus(DEFAULT_FINAL_STATUS);
        reportDetailHistory.setComment(DEFAULT_COMMENT);
    }

    @Test
    @Transactional
    public void createReportDetailHistory() throws Exception {
        int databaseSizeBeforeCreate = reportDetailHistoryRepository.findAll().size();

        // Create the ReportDetailHistory

        restReportDetailHistoryMockMvc.perform(post("/api/report-detail-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(reportDetailHistory)))
                .andExpect(status().isCreated());

        // Validate the ReportDetailHistory in the database
        List<ReportDetailHistory> reportDetailHistories = reportDetailHistoryRepository.findAll();
        assertThat(reportDetailHistories).hasSize(databaseSizeBeforeCreate + 1);
        ReportDetailHistory testReportDetailHistory = reportDetailHistories.get(reportDetailHistories.size() - 1);
        assertThat(testReportDetailHistory.getRecords()).isEqualTo(DEFAULT_RECORDS);
        assertThat(testReportDetailHistory.getIssues()).isEqualTo(DEFAULT_ISSUES);
        assertThat(testReportDetailHistory.getInitialStatus()).isEqualTo(DEFAULT_INITIAL_STATUS);
        assertThat(testReportDetailHistory.getFinalStatus()).isEqualTo(DEFAULT_FINAL_STATUS);
        assertThat(testReportDetailHistory.getComment()).isEqualTo(DEFAULT_COMMENT);
    }

    @Test
    @Transactional
    public void checkRecordsIsRequired() throws Exception {
        int databaseSizeBeforeTest = reportDetailHistoryRepository.findAll().size();
        // set the field null
        reportDetailHistory.setRecords(null);

        // Create the ReportDetailHistory, which fails.

        restReportDetailHistoryMockMvc.perform(post("/api/report-detail-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(reportDetailHistory)))
                .andExpect(status().isBadRequest());

        List<ReportDetailHistory> reportDetailHistories = reportDetailHistoryRepository.findAll();
        assertThat(reportDetailHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkIssuesIsRequired() throws Exception {
        int databaseSizeBeforeTest = reportDetailHistoryRepository.findAll().size();
        // set the field null
        reportDetailHistory.setIssues(null);

        // Create the ReportDetailHistory, which fails.

        restReportDetailHistoryMockMvc.perform(post("/api/report-detail-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(reportDetailHistory)))
                .andExpect(status().isBadRequest());

        List<ReportDetailHistory> reportDetailHistories = reportDetailHistoryRepository.findAll();
        assertThat(reportDetailHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkInitialStatusIsRequired() throws Exception {
        int databaseSizeBeforeTest = reportDetailHistoryRepository.findAll().size();
        // set the field null
        reportDetailHistory.setInitialStatus(null);

        // Create the ReportDetailHistory, which fails.

        restReportDetailHistoryMockMvc.perform(post("/api/report-detail-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(reportDetailHistory)))
                .andExpect(status().isBadRequest());

        List<ReportDetailHistory> reportDetailHistories = reportDetailHistoryRepository.findAll();
        assertThat(reportDetailHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkFinalStatusIsRequired() throws Exception {
        int databaseSizeBeforeTest = reportDetailHistoryRepository.findAll().size();
        // set the field null
        reportDetailHistory.setFinalStatus(null);

        // Create the ReportDetailHistory, which fails.

        restReportDetailHistoryMockMvc.perform(post("/api/report-detail-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(reportDetailHistory)))
                .andExpect(status().isBadRequest());

        List<ReportDetailHistory> reportDetailHistories = reportDetailHistoryRepository.findAll();
        assertThat(reportDetailHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllReportDetailHistories() throws Exception {
        // Initialize the database
        reportDetailHistoryRepository.saveAndFlush(reportDetailHistory);

        // Get all the reportDetailHistories
        restReportDetailHistoryMockMvc.perform(get("/api/report-detail-histories?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.[*].id").value(hasItem(reportDetailHistory.getId().intValue())))
                .andExpect(jsonPath("$.[*].records").value(hasItem(DEFAULT_RECORDS)))
                .andExpect(jsonPath("$.[*].issues").value(hasItem(DEFAULT_ISSUES)))
                .andExpect(jsonPath("$.[*].initialStatus").value(hasItem(DEFAULT_INITIAL_STATUS.toString())))
                .andExpect(jsonPath("$.[*].finalStatus").value(hasItem(DEFAULT_FINAL_STATUS.toString())))
                .andExpect(jsonPath("$.[*].comment").value(hasItem(DEFAULT_COMMENT.toString())));
    }

    @Test
    @Transactional
    public void getReportDetailHistory() throws Exception {
        // Initialize the database
        reportDetailHistoryRepository.saveAndFlush(reportDetailHistory);

        // Get the reportDetailHistory
        restReportDetailHistoryMockMvc.perform(get("/api/report-detail-histories/{id}", reportDetailHistory.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.id").value(reportDetailHistory.getId().intValue()))
            .andExpect(jsonPath("$.records").value(DEFAULT_RECORDS))
            .andExpect(jsonPath("$.issues").value(DEFAULT_ISSUES))
            .andExpect(jsonPath("$.initialStatus").value(DEFAULT_INITIAL_STATUS.toString()))
            .andExpect(jsonPath("$.finalStatus").value(DEFAULT_FINAL_STATUS.toString()))
            .andExpect(jsonPath("$.comment").value(DEFAULT_COMMENT.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingReportDetailHistory() throws Exception {
        // Get the reportDetailHistory
        restReportDetailHistoryMockMvc.perform(get("/api/report-detail-histories/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateReportDetailHistory() throws Exception {
        // Initialize the database
        reportDetailHistoryRepository.saveAndFlush(reportDetailHistory);
        int databaseSizeBeforeUpdate = reportDetailHistoryRepository.findAll().size();

        // Update the reportDetailHistory
        ReportDetailHistory updatedReportDetailHistory = new ReportDetailHistory();
        updatedReportDetailHistory.setId(reportDetailHistory.getId());
        updatedReportDetailHistory.setRecords(UPDATED_RECORDS);
        updatedReportDetailHistory.setIssues(UPDATED_ISSUES);
        updatedReportDetailHistory.setInitialStatus(UPDATED_INITIAL_STATUS);
        updatedReportDetailHistory.setFinalStatus(UPDATED_FINAL_STATUS);
        updatedReportDetailHistory.setComment(UPDATED_COMMENT);

        restReportDetailHistoryMockMvc.perform(put("/api/report-detail-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(updatedReportDetailHistory)))
                .andExpect(status().isOk());

        // Validate the ReportDetailHistory in the database
        List<ReportDetailHistory> reportDetailHistories = reportDetailHistoryRepository.findAll();
        assertThat(reportDetailHistories).hasSize(databaseSizeBeforeUpdate);
        ReportDetailHistory testReportDetailHistory = reportDetailHistories.get(reportDetailHistories.size() - 1);
        assertThat(testReportDetailHistory.getRecords()).isEqualTo(UPDATED_RECORDS);
        assertThat(testReportDetailHistory.getIssues()).isEqualTo(UPDATED_ISSUES);
        assertThat(testReportDetailHistory.getInitialStatus()).isEqualTo(UPDATED_INITIAL_STATUS);
        assertThat(testReportDetailHistory.getFinalStatus()).isEqualTo(UPDATED_FINAL_STATUS);
        assertThat(testReportDetailHistory.getComment()).isEqualTo(UPDATED_COMMENT);
    }

    @Test
    @Transactional
    public void deleteReportDetailHistory() throws Exception {
        // Initialize the database
        reportDetailHistoryRepository.saveAndFlush(reportDetailHistory);
        int databaseSizeBeforeDelete = reportDetailHistoryRepository.findAll().size();

        // Get the reportDetailHistory
        restReportDetailHistoryMockMvc.perform(delete("/api/report-detail-histories/{id}", reportDetailHistory.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate the database is empty
        List<ReportDetailHistory> reportDetailHistories = reportDetailHistoryRepository.findAll();
        assertThat(reportDetailHistories).hasSize(databaseSizeBeforeDelete - 1);
    }
}
