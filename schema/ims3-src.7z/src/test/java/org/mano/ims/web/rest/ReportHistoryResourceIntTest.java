package org.mano.ims.web.rest;

import org.mano.ims.ImsApp;
import org.mano.ims.domain.ReportHistory;
import org.mano.ims.repository.ReportHistoryRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


/**
 * Test class for the ReportHistoryResource REST controller.
 *
 * @see ReportHistoryResource
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = ImsApp.class)
@WebAppConfiguration
@IntegrationTest
public class ReportHistoryResourceIntTest {

    private static final String DEFAULT_INITIAL_STATUS = "AAAAA";
    private static final String UPDATED_INITIAL_STATUS = "BBBBB";
    private static final String DEFAULT_FINAL_STATUS = "AAAAA";
    private static final String UPDATED_FINAL_STATUS = "BBBBB";

    private static final LocalDate DEFAULT_BUSINESS_DATE = LocalDate.ofEpochDay(0L);
    private static final LocalDate UPDATED_BUSINESS_DATE = LocalDate.now(ZoneId.systemDefault());
    private static final String DEFAULT_COMMENT = "AAAAA";
    private static final String UPDATED_COMMENT = "BBBBB";

    @Inject
    private ReportHistoryRepository reportHistoryRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    private MockMvc restReportHistoryMockMvc;

    private ReportHistory reportHistory;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        ReportHistoryResource reportHistoryResource = new ReportHistoryResource();
        ReflectionTestUtils.setField(reportHistoryResource, "reportHistoryRepository", reportHistoryRepository);
        this.restReportHistoryMockMvc = MockMvcBuilders.standaloneSetup(reportHistoryResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    @Before
    public void initTest() {
        reportHistory = new ReportHistory();
        reportHistory.setInitialStatus(DEFAULT_INITIAL_STATUS);
        reportHistory.setFinalStatus(DEFAULT_FINAL_STATUS);
        reportHistory.setBusinessDate(DEFAULT_BUSINESS_DATE);
        reportHistory.setComment(DEFAULT_COMMENT);
    }

    @Test
    @Transactional
    public void createReportHistory() throws Exception {
        int databaseSizeBeforeCreate = reportHistoryRepository.findAll().size();

        // Create the ReportHistory

        restReportHistoryMockMvc.perform(post("/api/report-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(reportHistory)))
                .andExpect(status().isCreated());

        // Validate the ReportHistory in the database
        List<ReportHistory> reportHistories = reportHistoryRepository.findAll();
        assertThat(reportHistories).hasSize(databaseSizeBeforeCreate + 1);
        ReportHistory testReportHistory = reportHistories.get(reportHistories.size() - 1);
        assertThat(testReportHistory.getInitialStatus()).isEqualTo(DEFAULT_INITIAL_STATUS);
        assertThat(testReportHistory.getFinalStatus()).isEqualTo(DEFAULT_FINAL_STATUS);
        assertThat(testReportHistory.getBusinessDate()).isEqualTo(DEFAULT_BUSINESS_DATE);
        assertThat(testReportHistory.getComment()).isEqualTo(DEFAULT_COMMENT);
    }

    @Test
    @Transactional
    public void checkInitialStatusIsRequired() throws Exception {
        int databaseSizeBeforeTest = reportHistoryRepository.findAll().size();
        // set the field null
        reportHistory.setInitialStatus(null);

        // Create the ReportHistory, which fails.

        restReportHistoryMockMvc.perform(post("/api/report-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(reportHistory)))
                .andExpect(status().isBadRequest());

        List<ReportHistory> reportHistories = reportHistoryRepository.findAll();
        assertThat(reportHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkFinalStatusIsRequired() throws Exception {
        int databaseSizeBeforeTest = reportHistoryRepository.findAll().size();
        // set the field null
        reportHistory.setFinalStatus(null);

        // Create the ReportHistory, which fails.

        restReportHistoryMockMvc.perform(post("/api/report-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(reportHistory)))
                .andExpect(status().isBadRequest());

        List<ReportHistory> reportHistories = reportHistoryRepository.findAll();
        assertThat(reportHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkBusinessDateIsRequired() throws Exception {
        int databaseSizeBeforeTest = reportHistoryRepository.findAll().size();
        // set the field null
        reportHistory.setBusinessDate(null);

        // Create the ReportHistory, which fails.

        restReportHistoryMockMvc.perform(post("/api/report-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(reportHistory)))
                .andExpect(status().isBadRequest());

        List<ReportHistory> reportHistories = reportHistoryRepository.findAll();
        assertThat(reportHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllReportHistories() throws Exception {
        // Initialize the database
        reportHistoryRepository.saveAndFlush(reportHistory);

        // Get all the reportHistories
        restReportHistoryMockMvc.perform(get("/api/report-histories?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.[*].id").value(hasItem(reportHistory.getId().intValue())))
                .andExpect(jsonPath("$.[*].initialStatus").value(hasItem(DEFAULT_INITIAL_STATUS.toString())))
                .andExpect(jsonPath("$.[*].finalStatus").value(hasItem(DEFAULT_FINAL_STATUS.toString())))
                .andExpect(jsonPath("$.[*].businessDate").value(hasItem(DEFAULT_BUSINESS_DATE.toString())))
                .andExpect(jsonPath("$.[*].comment").value(hasItem(DEFAULT_COMMENT.toString())));
    }

    @Test
    @Transactional
    public void getReportHistory() throws Exception {
        // Initialize the database
        reportHistoryRepository.saveAndFlush(reportHistory);

        // Get the reportHistory
        restReportHistoryMockMvc.perform(get("/api/report-histories/{id}", reportHistory.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.id").value(reportHistory.getId().intValue()))
            .andExpect(jsonPath("$.initialStatus").value(DEFAULT_INITIAL_STATUS.toString()))
            .andExpect(jsonPath("$.finalStatus").value(DEFAULT_FINAL_STATUS.toString()))
            .andExpect(jsonPath("$.businessDate").value(DEFAULT_BUSINESS_DATE.toString()))
            .andExpect(jsonPath("$.comment").value(DEFAULT_COMMENT.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingReportHistory() throws Exception {
        // Get the reportHistory
        restReportHistoryMockMvc.perform(get("/api/report-histories/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateReportHistory() throws Exception {
        // Initialize the database
        reportHistoryRepository.saveAndFlush(reportHistory);
        int databaseSizeBeforeUpdate = reportHistoryRepository.findAll().size();

        // Update the reportHistory
        ReportHistory updatedReportHistory = new ReportHistory();
        updatedReportHistory.setId(reportHistory.getId());
        updatedReportHistory.setInitialStatus(UPDATED_INITIAL_STATUS);
        updatedReportHistory.setFinalStatus(UPDATED_FINAL_STATUS);
        updatedReportHistory.setBusinessDate(UPDATED_BUSINESS_DATE);
        updatedReportHistory.setComment(UPDATED_COMMENT);

        restReportHistoryMockMvc.perform(put("/api/report-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(updatedReportHistory)))
                .andExpect(status().isOk());

        // Validate the ReportHistory in the database
        List<ReportHistory> reportHistories = reportHistoryRepository.findAll();
        assertThat(reportHistories).hasSize(databaseSizeBeforeUpdate);
        ReportHistory testReportHistory = reportHistories.get(reportHistories.size() - 1);
        assertThat(testReportHistory.getInitialStatus()).isEqualTo(UPDATED_INITIAL_STATUS);
        assertThat(testReportHistory.getFinalStatus()).isEqualTo(UPDATED_FINAL_STATUS);
        assertThat(testReportHistory.getBusinessDate()).isEqualTo(UPDATED_BUSINESS_DATE);
        assertThat(testReportHistory.getComment()).isEqualTo(UPDATED_COMMENT);
    }

    @Test
    @Transactional
    public void deleteReportHistory() throws Exception {
        // Initialize the database
        reportHistoryRepository.saveAndFlush(reportHistory);
        int databaseSizeBeforeDelete = reportHistoryRepository.findAll().size();

        // Get the reportHistory
        restReportHistoryMockMvc.perform(delete("/api/report-histories/{id}", reportHistory.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate the database is empty
        List<ReportHistory> reportHistories = reportHistoryRepository.findAll();
        assertThat(reportHistories).hasSize(databaseSizeBeforeDelete - 1);
    }
}
