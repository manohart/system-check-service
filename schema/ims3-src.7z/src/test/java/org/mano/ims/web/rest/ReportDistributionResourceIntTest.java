package org.mano.ims.web.rest;

import org.mano.ims.ImsApp;
import org.mano.ims.domain.ReportDistribution;
import org.mano.ims.repository.ReportDistributionRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


/**
 * Test class for the ReportDistributionResource REST controller.
 *
 * @see ReportDistributionResource
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = ImsApp.class)
@WebAppConfiguration
@IntegrationTest
public class ReportDistributionResourceIntTest {

    private static final String DEFAULT_NAME = "AAAAA";
    private static final String UPDATED_NAME = "BBBBB";
    private static final String DEFAULT_SKIP_EMPTY_REPORT = "AAAAA";
    private static final String UPDATED_SKIP_EMPTY_REPORT = "BBBBB";

    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    @Inject
    private ReportDistributionRepository reportDistributionRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    private MockMvc restReportDistributionMockMvc;

    private ReportDistribution reportDistribution;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        ReportDistributionResource reportDistributionResource = new ReportDistributionResource();
        ReflectionTestUtils.setField(reportDistributionResource, "reportDistributionRepository", reportDistributionRepository);
        this.restReportDistributionMockMvc = MockMvcBuilders.standaloneSetup(reportDistributionResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    @Before
    public void initTest() {
        reportDistribution = new ReportDistribution();
        reportDistribution.setName(DEFAULT_NAME);
        reportDistribution.setSkipEmptyReport(DEFAULT_SKIP_EMPTY_REPORT);
        reportDistribution.setIsActive(DEFAULT_IS_ACTIVE);
    }

    @Test
    @Transactional
    public void createReportDistribution() throws Exception {
        int databaseSizeBeforeCreate = reportDistributionRepository.findAll().size();

        // Create the ReportDistribution

        restReportDistributionMockMvc.perform(post("/api/report-distributions")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(reportDistribution)))
                .andExpect(status().isCreated());

        // Validate the ReportDistribution in the database
        List<ReportDistribution> reportDistributions = reportDistributionRepository.findAll();
        assertThat(reportDistributions).hasSize(databaseSizeBeforeCreate + 1);
        ReportDistribution testReportDistribution = reportDistributions.get(reportDistributions.size() - 1);
        assertThat(testReportDistribution.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testReportDistribution.getSkipEmptyReport()).isEqualTo(DEFAULT_SKIP_EMPTY_REPORT);
        assertThat(testReportDistribution.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
    }

    @Test
    @Transactional
    public void checkSkipEmptyReportIsRequired() throws Exception {
        int databaseSizeBeforeTest = reportDistributionRepository.findAll().size();
        // set the field null
        reportDistribution.setSkipEmptyReport(null);

        // Create the ReportDistribution, which fails.

        restReportDistributionMockMvc.perform(post("/api/report-distributions")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(reportDistribution)))
                .andExpect(status().isBadRequest());

        List<ReportDistribution> reportDistributions = reportDistributionRepository.findAll();
        assertThat(reportDistributions).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkIsActiveIsRequired() throws Exception {
        int databaseSizeBeforeTest = reportDistributionRepository.findAll().size();
        // set the field null
        reportDistribution.setIsActive(null);

        // Create the ReportDistribution, which fails.

        restReportDistributionMockMvc.perform(post("/api/report-distributions")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(reportDistribution)))
                .andExpect(status().isBadRequest());

        List<ReportDistribution> reportDistributions = reportDistributionRepository.findAll();
        assertThat(reportDistributions).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllReportDistributions() throws Exception {
        // Initialize the database
        reportDistributionRepository.saveAndFlush(reportDistribution);

        // Get all the reportDistributions
        restReportDistributionMockMvc.perform(get("/api/report-distributions?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.[*].id").value(hasItem(reportDistribution.getId().intValue())))
                .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
                .andExpect(jsonPath("$.[*].skipEmptyReport").value(hasItem(DEFAULT_SKIP_EMPTY_REPORT.toString())))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())));
    }

    @Test
    @Transactional
    public void getReportDistribution() throws Exception {
        // Initialize the database
        reportDistributionRepository.saveAndFlush(reportDistribution);

        // Get the reportDistribution
        restReportDistributionMockMvc.perform(get("/api/report-distributions/{id}", reportDistribution.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.id").value(reportDistribution.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.skipEmptyReport").value(DEFAULT_SKIP_EMPTY_REPORT.toString()))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()));
    }

    @Test
    @Transactional
    public void getNonExistingReportDistribution() throws Exception {
        // Get the reportDistribution
        restReportDistributionMockMvc.perform(get("/api/report-distributions/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateReportDistribution() throws Exception {
        // Initialize the database
        reportDistributionRepository.saveAndFlush(reportDistribution);
        int databaseSizeBeforeUpdate = reportDistributionRepository.findAll().size();

        // Update the reportDistribution
        ReportDistribution updatedReportDistribution = new ReportDistribution();
        updatedReportDistribution.setId(reportDistribution.getId());
        updatedReportDistribution.setName(UPDATED_NAME);
        updatedReportDistribution.setSkipEmptyReport(UPDATED_SKIP_EMPTY_REPORT);
        updatedReportDistribution.setIsActive(UPDATED_IS_ACTIVE);

        restReportDistributionMockMvc.perform(put("/api/report-distributions")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(updatedReportDistribution)))
                .andExpect(status().isOk());

        // Validate the ReportDistribution in the database
        List<ReportDistribution> reportDistributions = reportDistributionRepository.findAll();
        assertThat(reportDistributions).hasSize(databaseSizeBeforeUpdate);
        ReportDistribution testReportDistribution = reportDistributions.get(reportDistributions.size() - 1);
        assertThat(testReportDistribution.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testReportDistribution.getSkipEmptyReport()).isEqualTo(UPDATED_SKIP_EMPTY_REPORT);
        assertThat(testReportDistribution.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
    }

    @Test
    @Transactional
    public void deleteReportDistribution() throws Exception {
        // Initialize the database
        reportDistributionRepository.saveAndFlush(reportDistribution);
        int databaseSizeBeforeDelete = reportDistributionRepository.findAll().size();

        // Get the reportDistribution
        restReportDistributionMockMvc.perform(delete("/api/report-distributions/{id}", reportDistribution.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate the database is empty
        List<ReportDistribution> reportDistributions = reportDistributionRepository.findAll();
        assertThat(reportDistributions).hasSize(databaseSizeBeforeDelete - 1);
    }
}
