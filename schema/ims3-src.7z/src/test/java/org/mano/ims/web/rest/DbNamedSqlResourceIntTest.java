package org.mano.ims.web.rest;

import org.mano.ims.ImsApp;
import org.mano.ims.domain.DbNamedSql;
import org.mano.ims.repository.DbNamedSqlRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


/**
 * Test class for the DbNamedSqlResource REST controller.
 *
 * @see DbNamedSqlResource
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = ImsApp.class)
@WebAppConfiguration
@IntegrationTest
public class DbNamedSqlResourceIntTest {

    private static final String DEFAULT_NAMESPACE = "AAAAA";
    private static final String UPDATED_NAMESPACE = "BBBBB";
    private static final String DEFAULT_STATEMENT_ID = "AAAAA";
    private static final String UPDATED_STATEMENT_ID = "BBBBB";
    private static final String DEFAULT_DESCRIPTION = "AAAAA";
    private static final String UPDATED_DESCRIPTION = "BBBBB";

    @Inject
    private DbNamedSqlRepository dbNamedSqlRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    private MockMvc restDbNamedSqlMockMvc;

    private DbNamedSql dbNamedSql;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        DbNamedSqlResource dbNamedSqlResource = new DbNamedSqlResource();
        ReflectionTestUtils.setField(dbNamedSqlResource, "dbNamedSqlRepository", dbNamedSqlRepository);
        this.restDbNamedSqlMockMvc = MockMvcBuilders.standaloneSetup(dbNamedSqlResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    @Before
    public void initTest() {
        dbNamedSql = new DbNamedSql();
        dbNamedSql.setNamespace(DEFAULT_NAMESPACE);
        dbNamedSql.setStatementId(DEFAULT_STATEMENT_ID);
        dbNamedSql.setDescription(DEFAULT_DESCRIPTION);
    }

    @Test
    @Transactional
    public void createDbNamedSql() throws Exception {
        int databaseSizeBeforeCreate = dbNamedSqlRepository.findAll().size();

        // Create the DbNamedSql

        restDbNamedSqlMockMvc.perform(post("/api/db-named-sqls")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(dbNamedSql)))
                .andExpect(status().isCreated());

        // Validate the DbNamedSql in the database
        List<DbNamedSql> dbNamedSqls = dbNamedSqlRepository.findAll();
        assertThat(dbNamedSqls).hasSize(databaseSizeBeforeCreate + 1);
        DbNamedSql testDbNamedSql = dbNamedSqls.get(dbNamedSqls.size() - 1);
        assertThat(testDbNamedSql.getNamespace()).isEqualTo(DEFAULT_NAMESPACE);
        assertThat(testDbNamedSql.getStatementId()).isEqualTo(DEFAULT_STATEMENT_ID);
        assertThat(testDbNamedSql.getDescription()).isEqualTo(DEFAULT_DESCRIPTION);
    }

    @Test
    @Transactional
    public void checkNamespaceIsRequired() throws Exception {
        int databaseSizeBeforeTest = dbNamedSqlRepository.findAll().size();
        // set the field null
        dbNamedSql.setNamespace(null);

        // Create the DbNamedSql, which fails.

        restDbNamedSqlMockMvc.perform(post("/api/db-named-sqls")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(dbNamedSql)))
                .andExpect(status().isBadRequest());

        List<DbNamedSql> dbNamedSqls = dbNamedSqlRepository.findAll();
        assertThat(dbNamedSqls).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkStatementIdIsRequired() throws Exception {
        int databaseSizeBeforeTest = dbNamedSqlRepository.findAll().size();
        // set the field null
        dbNamedSql.setStatementId(null);

        // Create the DbNamedSql, which fails.

        restDbNamedSqlMockMvc.perform(post("/api/db-named-sqls")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(dbNamedSql)))
                .andExpect(status().isBadRequest());

        List<DbNamedSql> dbNamedSqls = dbNamedSqlRepository.findAll();
        assertThat(dbNamedSqls).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkDescriptionIsRequired() throws Exception {
        int databaseSizeBeforeTest = dbNamedSqlRepository.findAll().size();
        // set the field null
        dbNamedSql.setDescription(null);

        // Create the DbNamedSql, which fails.

        restDbNamedSqlMockMvc.perform(post("/api/db-named-sqls")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(dbNamedSql)))
                .andExpect(status().isBadRequest());

        List<DbNamedSql> dbNamedSqls = dbNamedSqlRepository.findAll();
        assertThat(dbNamedSqls).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllDbNamedSqls() throws Exception {
        // Initialize the database
        dbNamedSqlRepository.saveAndFlush(dbNamedSql);

        // Get all the dbNamedSqls
        restDbNamedSqlMockMvc.perform(get("/api/db-named-sqls?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.[*].id").value(hasItem(dbNamedSql.getId().intValue())))
                .andExpect(jsonPath("$.[*].namespace").value(hasItem(DEFAULT_NAMESPACE.toString())))
                .andExpect(jsonPath("$.[*].statementId").value(hasItem(DEFAULT_STATEMENT_ID.toString())))
                .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())));
    }

    @Test
    @Transactional
    public void getDbNamedSql() throws Exception {
        // Initialize the database
        dbNamedSqlRepository.saveAndFlush(dbNamedSql);

        // Get the dbNamedSql
        restDbNamedSqlMockMvc.perform(get("/api/db-named-sqls/{id}", dbNamedSql.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.id").value(dbNamedSql.getId().intValue()))
            .andExpect(jsonPath("$.namespace").value(DEFAULT_NAMESPACE.toString()))
            .andExpect(jsonPath("$.statementId").value(DEFAULT_STATEMENT_ID.toString()))
            .andExpect(jsonPath("$.description").value(DEFAULT_DESCRIPTION.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingDbNamedSql() throws Exception {
        // Get the dbNamedSql
        restDbNamedSqlMockMvc.perform(get("/api/db-named-sqls/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateDbNamedSql() throws Exception {
        // Initialize the database
        dbNamedSqlRepository.saveAndFlush(dbNamedSql);
        int databaseSizeBeforeUpdate = dbNamedSqlRepository.findAll().size();

        // Update the dbNamedSql
        DbNamedSql updatedDbNamedSql = new DbNamedSql();
        updatedDbNamedSql.setId(dbNamedSql.getId());
        updatedDbNamedSql.setNamespace(UPDATED_NAMESPACE);
        updatedDbNamedSql.setStatementId(UPDATED_STATEMENT_ID);
        updatedDbNamedSql.setDescription(UPDATED_DESCRIPTION);

        restDbNamedSqlMockMvc.perform(put("/api/db-named-sqls")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(updatedDbNamedSql)))
                .andExpect(status().isOk());

        // Validate the DbNamedSql in the database
        List<DbNamedSql> dbNamedSqls = dbNamedSqlRepository.findAll();
        assertThat(dbNamedSqls).hasSize(databaseSizeBeforeUpdate);
        DbNamedSql testDbNamedSql = dbNamedSqls.get(dbNamedSqls.size() - 1);
        assertThat(testDbNamedSql.getNamespace()).isEqualTo(UPDATED_NAMESPACE);
        assertThat(testDbNamedSql.getStatementId()).isEqualTo(UPDATED_STATEMENT_ID);
        assertThat(testDbNamedSql.getDescription()).isEqualTo(UPDATED_DESCRIPTION);
    }

    @Test
    @Transactional
    public void deleteDbNamedSql() throws Exception {
        // Initialize the database
        dbNamedSqlRepository.saveAndFlush(dbNamedSql);
        int databaseSizeBeforeDelete = dbNamedSqlRepository.findAll().size();

        // Get the dbNamedSql
        restDbNamedSqlMockMvc.perform(delete("/api/db-named-sqls/{id}", dbNamedSql.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate the database is empty
        List<DbNamedSql> dbNamedSqls = dbNamedSqlRepository.findAll();
        assertThat(dbNamedSqls).hasSize(databaseSizeBeforeDelete - 1);
    }
}
