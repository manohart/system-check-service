package org.mano.ims.web.rest;

import org.mano.ims.ImsApp;
import org.mano.ims.domain.Upstream;
import org.mano.ims.repository.UpstreamRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


/**
 * Test class for the UpstreamResource REST controller.
 *
 * @see UpstreamResource
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = ImsApp.class)
@WebAppConfiguration
@IntegrationTest
public class UpstreamResourceIntTest {

    private static final String DEFAULT_NAME = "AAAAA";
    private static final String UPDATED_NAME = "BBBBB";
    private static final String DEFAULT_OWNER_EMAIL_ID = "AAAAA";
    private static final String UPDATED_OWNER_EMAIL_ID = "BBBBB";
    private static final String DEFAULT_TEAM_DL_EMAIL_ID = "AAAAA";
    private static final String UPDATED_TEAM_DL_EMAIL_ID = "BBBBB";

    @Inject
    private UpstreamRepository upstreamRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    private MockMvc restUpstreamMockMvc;

    private Upstream upstream;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        UpstreamResource upstreamResource = new UpstreamResource();
        ReflectionTestUtils.setField(upstreamResource, "upstreamRepository", upstreamRepository);
        this.restUpstreamMockMvc = MockMvcBuilders.standaloneSetup(upstreamResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    @Before
    public void initTest() {
        upstream = new Upstream();
        upstream.setName(DEFAULT_NAME);
        upstream.setOwnerEmailId(DEFAULT_OWNER_EMAIL_ID);
        upstream.setTeamDlEmailId(DEFAULT_TEAM_DL_EMAIL_ID);
    }

    @Test
    @Transactional
    public void createUpstream() throws Exception {
        int databaseSizeBeforeCreate = upstreamRepository.findAll().size();

        // Create the Upstream

        restUpstreamMockMvc.perform(post("/api/upstreams")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(upstream)))
                .andExpect(status().isCreated());

        // Validate the Upstream in the database
        List<Upstream> upstreams = upstreamRepository.findAll();
        assertThat(upstreams).hasSize(databaseSizeBeforeCreate + 1);
        Upstream testUpstream = upstreams.get(upstreams.size() - 1);
        assertThat(testUpstream.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testUpstream.getOwnerEmailId()).isEqualTo(DEFAULT_OWNER_EMAIL_ID);
        assertThat(testUpstream.getTeamDlEmailId()).isEqualTo(DEFAULT_TEAM_DL_EMAIL_ID);
    }

    @Test
    @Transactional
    public void checkNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = upstreamRepository.findAll().size();
        // set the field null
        upstream.setName(null);

        // Create the Upstream, which fails.

        restUpstreamMockMvc.perform(post("/api/upstreams")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(upstream)))
                .andExpect(status().isBadRequest());

        List<Upstream> upstreams = upstreamRepository.findAll();
        assertThat(upstreams).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkOwnerEmailIdIsRequired() throws Exception {
        int databaseSizeBeforeTest = upstreamRepository.findAll().size();
        // set the field null
        upstream.setOwnerEmailId(null);

        // Create the Upstream, which fails.

        restUpstreamMockMvc.perform(post("/api/upstreams")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(upstream)))
                .andExpect(status().isBadRequest());

        List<Upstream> upstreams = upstreamRepository.findAll();
        assertThat(upstreams).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkTeamDlEmailIdIsRequired() throws Exception {
        int databaseSizeBeforeTest = upstreamRepository.findAll().size();
        // set the field null
        upstream.setTeamDlEmailId(null);

        // Create the Upstream, which fails.

        restUpstreamMockMvc.perform(post("/api/upstreams")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(upstream)))
                .andExpect(status().isBadRequest());

        List<Upstream> upstreams = upstreamRepository.findAll();
        assertThat(upstreams).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllUpstreams() throws Exception {
        // Initialize the database
        upstreamRepository.saveAndFlush(upstream);

        // Get all the upstreams
        restUpstreamMockMvc.perform(get("/api/upstreams?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.[*].id").value(hasItem(upstream.getId().intValue())))
                .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
                .andExpect(jsonPath("$.[*].ownerEmailId").value(hasItem(DEFAULT_OWNER_EMAIL_ID.toString())))
                .andExpect(jsonPath("$.[*].teamDlEmailId").value(hasItem(DEFAULT_TEAM_DL_EMAIL_ID.toString())));
    }

    @Test
    @Transactional
    public void getUpstream() throws Exception {
        // Initialize the database
        upstreamRepository.saveAndFlush(upstream);

        // Get the upstream
        restUpstreamMockMvc.perform(get("/api/upstreams/{id}", upstream.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.id").value(upstream.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.ownerEmailId").value(DEFAULT_OWNER_EMAIL_ID.toString()))
            .andExpect(jsonPath("$.teamDlEmailId").value(DEFAULT_TEAM_DL_EMAIL_ID.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingUpstream() throws Exception {
        // Get the upstream
        restUpstreamMockMvc.perform(get("/api/upstreams/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateUpstream() throws Exception {
        // Initialize the database
        upstreamRepository.saveAndFlush(upstream);
        int databaseSizeBeforeUpdate = upstreamRepository.findAll().size();

        // Update the upstream
        Upstream updatedUpstream = new Upstream();
        updatedUpstream.setId(upstream.getId());
        updatedUpstream.setName(UPDATED_NAME);
        updatedUpstream.setOwnerEmailId(UPDATED_OWNER_EMAIL_ID);
        updatedUpstream.setTeamDlEmailId(UPDATED_TEAM_DL_EMAIL_ID);

        restUpstreamMockMvc.perform(put("/api/upstreams")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(updatedUpstream)))
                .andExpect(status().isOk());

        // Validate the Upstream in the database
        List<Upstream> upstreams = upstreamRepository.findAll();
        assertThat(upstreams).hasSize(databaseSizeBeforeUpdate);
        Upstream testUpstream = upstreams.get(upstreams.size() - 1);
        assertThat(testUpstream.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testUpstream.getOwnerEmailId()).isEqualTo(UPDATED_OWNER_EMAIL_ID);
        assertThat(testUpstream.getTeamDlEmailId()).isEqualTo(UPDATED_TEAM_DL_EMAIL_ID);
    }

    @Test
    @Transactional
    public void deleteUpstream() throws Exception {
        // Initialize the database
        upstreamRepository.saveAndFlush(upstream);
        int databaseSizeBeforeDelete = upstreamRepository.findAll().size();

        // Get the upstream
        restUpstreamMockMvc.perform(delete("/api/upstreams/{id}", upstream.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate the database is empty
        List<Upstream> upstreams = upstreamRepository.findAll();
        assertThat(upstreams).hasSize(databaseSizeBeforeDelete - 1);
    }
}
