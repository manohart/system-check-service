package org.mano.ims.web.rest;

import org.mano.ims.ImsApp;
import org.mano.ims.domain.EmailConfig;
import org.mano.ims.repository.EmailConfigRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


/**
 * Test class for the EmailConfigResource REST controller.
 *
 * @see EmailConfigResource
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = ImsApp.class)
@WebAppConfiguration
@IntegrationTest
public class EmailConfigResourceIntTest {

    private static final String DEFAULT_NAME = "AAAAA";
    private static final String UPDATED_NAME = "BBBBB";
    private static final String DEFAULT_DESCRIPTION = "AAAAA";
    private static final String UPDATED_DESCRIPTION = "BBBBB";
    private static final String DEFAULT_FROM_ADDRESS = "AAAAA";
    private static final String UPDATED_FROM_ADDRESS = "BBBBB";
    private static final String DEFAULT_TO_ADDRESS = "AAAAA";
    private static final String UPDATED_TO_ADDRESS = "BBBBB";
    private static final String DEFAULT_CC_ADDRESS = "AAAAA";
    private static final String UPDATED_CC_ADDRESS = "BBBBB";

    @Inject
    private EmailConfigRepository emailConfigRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    private MockMvc restEmailConfigMockMvc;

    private EmailConfig emailConfig;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        EmailConfigResource emailConfigResource = new EmailConfigResource();
        ReflectionTestUtils.setField(emailConfigResource, "emailConfigRepository", emailConfigRepository);
        this.restEmailConfigMockMvc = MockMvcBuilders.standaloneSetup(emailConfigResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    @Before
    public void initTest() {
        emailConfig = new EmailConfig();
        emailConfig.setName(DEFAULT_NAME);
        emailConfig.setDescription(DEFAULT_DESCRIPTION);
        emailConfig.setFromAddress(DEFAULT_FROM_ADDRESS);
        emailConfig.setToAddress(DEFAULT_TO_ADDRESS);
        emailConfig.setCcAddress(DEFAULT_CC_ADDRESS);
    }

    @Test
    @Transactional
    public void createEmailConfig() throws Exception {
        int databaseSizeBeforeCreate = emailConfigRepository.findAll().size();

        // Create the EmailConfig

        restEmailConfigMockMvc.perform(post("/api/email-configs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(emailConfig)))
                .andExpect(status().isCreated());

        // Validate the EmailConfig in the database
        List<EmailConfig> emailConfigs = emailConfigRepository.findAll();
        assertThat(emailConfigs).hasSize(databaseSizeBeforeCreate + 1);
        EmailConfig testEmailConfig = emailConfigs.get(emailConfigs.size() - 1);
        assertThat(testEmailConfig.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testEmailConfig.getDescription()).isEqualTo(DEFAULT_DESCRIPTION);
        assertThat(testEmailConfig.getFromAddress()).isEqualTo(DEFAULT_FROM_ADDRESS);
        assertThat(testEmailConfig.getToAddress()).isEqualTo(DEFAULT_TO_ADDRESS);
        assertThat(testEmailConfig.getCcAddress()).isEqualTo(DEFAULT_CC_ADDRESS);
    }

    @Test
    @Transactional
    public void checkNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = emailConfigRepository.findAll().size();
        // set the field null
        emailConfig.setName(null);

        // Create the EmailConfig, which fails.

        restEmailConfigMockMvc.perform(post("/api/email-configs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(emailConfig)))
                .andExpect(status().isBadRequest());

        List<EmailConfig> emailConfigs = emailConfigRepository.findAll();
        assertThat(emailConfigs).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkDescriptionIsRequired() throws Exception {
        int databaseSizeBeforeTest = emailConfigRepository.findAll().size();
        // set the field null
        emailConfig.setDescription(null);

        // Create the EmailConfig, which fails.

        restEmailConfigMockMvc.perform(post("/api/email-configs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(emailConfig)))
                .andExpect(status().isBadRequest());

        List<EmailConfig> emailConfigs = emailConfigRepository.findAll();
        assertThat(emailConfigs).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkFromAddressIsRequired() throws Exception {
        int databaseSizeBeforeTest = emailConfigRepository.findAll().size();
        // set the field null
        emailConfig.setFromAddress(null);

        // Create the EmailConfig, which fails.

        restEmailConfigMockMvc.perform(post("/api/email-configs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(emailConfig)))
                .andExpect(status().isBadRequest());

        List<EmailConfig> emailConfigs = emailConfigRepository.findAll();
        assertThat(emailConfigs).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkToAddressIsRequired() throws Exception {
        int databaseSizeBeforeTest = emailConfigRepository.findAll().size();
        // set the field null
        emailConfig.setToAddress(null);

        // Create the EmailConfig, which fails.

        restEmailConfigMockMvc.perform(post("/api/email-configs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(emailConfig)))
                .andExpect(status().isBadRequest());

        List<EmailConfig> emailConfigs = emailConfigRepository.findAll();
        assertThat(emailConfigs).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkCcAddressIsRequired() throws Exception {
        int databaseSizeBeforeTest = emailConfigRepository.findAll().size();
        // set the field null
        emailConfig.setCcAddress(null);

        // Create the EmailConfig, which fails.

        restEmailConfigMockMvc.perform(post("/api/email-configs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(emailConfig)))
                .andExpect(status().isBadRequest());

        List<EmailConfig> emailConfigs = emailConfigRepository.findAll();
        assertThat(emailConfigs).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllEmailConfigs() throws Exception {
        // Initialize the database
        emailConfigRepository.saveAndFlush(emailConfig);

        // Get all the emailConfigs
        restEmailConfigMockMvc.perform(get("/api/email-configs?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.[*].id").value(hasItem(emailConfig.getId().intValue())))
                .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
                .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
                .andExpect(jsonPath("$.[*].fromAddress").value(hasItem(DEFAULT_FROM_ADDRESS.toString())))
                .andExpect(jsonPath("$.[*].toAddress").value(hasItem(DEFAULT_TO_ADDRESS.toString())))
                .andExpect(jsonPath("$.[*].ccAddress").value(hasItem(DEFAULT_CC_ADDRESS.toString())));
    }

    @Test
    @Transactional
    public void getEmailConfig() throws Exception {
        // Initialize the database
        emailConfigRepository.saveAndFlush(emailConfig);

        // Get the emailConfig
        restEmailConfigMockMvc.perform(get("/api/email-configs/{id}", emailConfig.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.id").value(emailConfig.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.description").value(DEFAULT_DESCRIPTION.toString()))
            .andExpect(jsonPath("$.fromAddress").value(DEFAULT_FROM_ADDRESS.toString()))
            .andExpect(jsonPath("$.toAddress").value(DEFAULT_TO_ADDRESS.toString()))
            .andExpect(jsonPath("$.ccAddress").value(DEFAULT_CC_ADDRESS.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingEmailConfig() throws Exception {
        // Get the emailConfig
        restEmailConfigMockMvc.perform(get("/api/email-configs/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateEmailConfig() throws Exception {
        // Initialize the database
        emailConfigRepository.saveAndFlush(emailConfig);
        int databaseSizeBeforeUpdate = emailConfigRepository.findAll().size();

        // Update the emailConfig
        EmailConfig updatedEmailConfig = new EmailConfig();
        updatedEmailConfig.setId(emailConfig.getId());
        updatedEmailConfig.setName(UPDATED_NAME);
        updatedEmailConfig.setDescription(UPDATED_DESCRIPTION);
        updatedEmailConfig.setFromAddress(UPDATED_FROM_ADDRESS);
        updatedEmailConfig.setToAddress(UPDATED_TO_ADDRESS);
        updatedEmailConfig.setCcAddress(UPDATED_CC_ADDRESS);

        restEmailConfigMockMvc.perform(put("/api/email-configs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(updatedEmailConfig)))
                .andExpect(status().isOk());

        // Validate the EmailConfig in the database
        List<EmailConfig> emailConfigs = emailConfigRepository.findAll();
        assertThat(emailConfigs).hasSize(databaseSizeBeforeUpdate);
        EmailConfig testEmailConfig = emailConfigs.get(emailConfigs.size() - 1);
        assertThat(testEmailConfig.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testEmailConfig.getDescription()).isEqualTo(UPDATED_DESCRIPTION);
        assertThat(testEmailConfig.getFromAddress()).isEqualTo(UPDATED_FROM_ADDRESS);
        assertThat(testEmailConfig.getToAddress()).isEqualTo(UPDATED_TO_ADDRESS);
        assertThat(testEmailConfig.getCcAddress()).isEqualTo(UPDATED_CC_ADDRESS);
    }

    @Test
    @Transactional
    public void deleteEmailConfig() throws Exception {
        // Initialize the database
        emailConfigRepository.saveAndFlush(emailConfig);
        int databaseSizeBeforeDelete = emailConfigRepository.findAll().size();

        // Get the emailConfig
        restEmailConfigMockMvc.perform(delete("/api/email-configs/{id}", emailConfig.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate the database is empty
        List<EmailConfig> emailConfigs = emailConfigRepository.findAll();
        assertThat(emailConfigs).hasSize(databaseSizeBeforeDelete - 1);
    }
}
